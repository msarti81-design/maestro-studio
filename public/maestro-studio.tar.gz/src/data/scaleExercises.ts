export interface ScaleExercise {
  id: string;
  name: string;
  category: 'Hanon (Indipendenza)' | 'Scale Maggiori' | 'Scale Minori' | 'Arpeggi' | 'Blues & Pentatoniche';
  description: string;
  notes: string[];
  fingering: number[]; // 1 = Pollice, 2 = Indice, 3 = Medio, 4 = Anulare, 5 = Mignolo
  difficulty: 'Facile' | 'Intermedio' | 'Avanzato';
  hand?: 'right' | 'left';
  tempoBpm: number;
  keySignature: string;
  tips?: string[];
}

export const FINGER_NAMES: Record<number, { name: string; short: string; icon: string }> = {
  1: { name: 'Pollice', short: '1', icon: '👍' },
  2: { name: 'Indice', short: '2', icon: '☝️' },
  3: { name: 'Medio', short: '3', icon: '🖐️' },
  4: { name: 'Anulare', short: '4', icon: '💍' },
  5: { name: 'Mignolo', short: '5', icon: '🤙' },
};

export const SCALE_EXERCISES: ScaleExercise[] = [
  {
    id: 'scale_c_major',
    name: 'Scala di DO Maggiore (C Major)',
    category: 'Scale Maggiori',
    description: 'La scala regina senza alterazioni. Perfetta per apprendere il fondamentale passaggio del pollice sotto il 3° dito sul Fa.',
    notes: ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5', 'B4', 'A4', 'G4', 'F4', 'E4', 'D4', 'C4'],
    fingering: [1, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 80,
    keySignature: 'DO Magg / C (Nessuna alterazione)',
    tips: [
      'Tieni la mano rilassata e arrotondata come se tenessi una mela.',
      'Sul passaggio da Mi4 a Fa4, fai scorrere agilmente il pollice (1) sotto il dito medio (3).',
      'Nella discesa, il medio (3) passa sopra il pollice (1) per tornare su Mi4.',
    ],
  },
  {
    id: 'hanon_1',
    name: 'Hanon N. 1 (Dita 1-5 Agilità)',
    category: 'Hanon (Indipendenza)',
    description: 'Il classico esercizio del virtuoso pianista: scioglie le 5 dita, sviluppa indipendenza e uguaglianza del tocco.',
    notes: ['C4', 'E4', 'F4', 'G4', 'A4', 'G4', 'F4', 'E4', 'D4', 'F4', 'G4', 'A4', 'B4', 'A4', 'G4', 'F4', 'E4'],
    fingering: [1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4, 5, 4, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 84,
    keySignature: 'DO Magg / C',
    tips: [
      'Mantieni i polsi allineati e fermi: lavorano solo le articolazioni delle dita.',
      'Suona con tocco scandito ed eguale intensità per ciascuna nota.',
    ],
  },
  {
    id: 'scale_g_major',
    name: 'Scala di SOL Maggiore (G Major - 1 ♯)',
    category: 'Scale Maggiori',
    description: 'Scala con il FA diesis (Fa♯). Ottima per abituare le dita ai tasti neri mantenendo la diteggiatura standard.',
    notes: ['G3', 'A3', 'B3', 'C4', 'D4', 'E4', 'F#4', 'G4', 'F#4', 'E4', 'D4', 'C4', 'B3', 'A3', 'G3'],
    fingering: [1, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 80,
    keySignature: 'SOL Magg / G (1 Diesis: F♯)',
    tips: [
      'Il dito 4 (anulare) tocca comodamente il Fa♯4 tasto nero prima del Sol con il mignolo (5).',
      'Passaggio del pollice sul Do4 dopo il Si3.',
    ],
  },
  {
    id: 'scale_f_major',
    name: 'Scala di FA Maggiore (F Major - 1 ♭)',
    category: 'Scale Maggiori',
    description: 'Scala fondamentale con il SI bemolle (Si♭). Utilizza il dito 4 sul Si♭ anziché il pollice!',
    notes: ['F3', 'G3', 'A3', 'Bb3', 'C4', 'D4', 'E4', 'F4', 'E4', 'D4', 'C4', 'Bb3', 'A3', 'G3', 'F3'],
    fingering: [1, 2, 3, 4, 1, 2, 3, 4, 3, 2, 1, 4, 3, 2, 1],
    difficulty: 'Intermedio',
    hand: 'right',
    tempoBpm: 75,
    keySignature: 'FA Magg / F (1 Bemolle: B♭)',
    tips: [
      'Attenzione: non passare il pollice sul Si♭! Usa il dito 4 sul Si♭, poi passa il pollice sotto sul Do4.',
    ],
  },
  {
    id: 'scale_d_major',
    name: 'Scala di RE Maggiore (D Major - 2 ♯)',
    category: 'Scale Maggiori',
    description: 'Scala brillante con due diesis: FA diesis e DO diesis. Ottima per l’impostazione ergonomica su tasti bianchi e neri.',
    notes: ['D4', 'E4', 'F#4', 'G4', 'A4', 'B4', 'C#5', 'D5', 'C#5', 'B4', 'A4', 'G4', 'F#4', 'E4', 'D4'],
    fingering: [1, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 2, 1],
    difficulty: 'Intermedio',
    hand: 'right',
    tempoBpm: 80,
    keySignature: 'RE Magg / D (2 Diesis: F♯, C♯)',
    tips: [
      'Il medio (3) suona il Fa♯4, poi il pollice (1) passa sotto sul Sol4.',
      'L’anulare (4) suona il Do♯5.',
    ],
  },
  {
    id: 'scale_a_minor',
    name: 'Scala di LA Minore Naturale (A Minor)',
    category: 'Scale Minori',
    description: 'La relativa minore di Do Maggiore: tutta sui tasti bianchi, ma con carattere meditativo e malinconico.',
    notes: ['A3', 'B3', 'C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'G4', 'F4', 'E4', 'D4', 'C4', 'B3', 'A3'],
    fingering: [1, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 75,
    keySignature: 'LA Min / Am (Nessuna alterazione)',
    tips: [
      'Passaggio del pollice (1) sotto il 3° dito sul Re4.',
    ],
  },
  {
    id: 'scale_e_minor',
    name: 'Scala di MI Minore Armonica (E Minor)',
    category: 'Scale Minori',
    description: 'Scala minore con 7° grado innalzato (Re♯): crea il suggestivo intervallo di seconda aumentata tipico della musica classica.',
    notes: ['E4', 'F#4', 'G4', 'A4', 'B4', 'C5', 'D#5', 'E5', 'D#5', 'C5', 'B4', 'A4', 'G4', 'F#4', 'E4'],
    fingering: [1, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 2, 1],
    difficulty: 'Intermedio',
    hand: 'right',
    tempoBpm: 75,
    keySignature: 'MI Min / Em (F♯, D♯)',
    tips: [
      'Attenzione al Re♯5 suonato con il 4° dito prima del Mi5 col mignolo.',
    ],
  },
  {
    id: 'arpeggio_c_major',
    name: 'Arpeggio di DO Maggiore (C Major Triad)',
    category: 'Arpeggi',
    description: 'Esercizio fondamentale di estensione e fluidità sui gradi dell’accordo fondamentale Do - Mi - Sol - Do.',
    notes: ['C4', 'E4', 'G4', 'C5', 'G4', 'E4', 'C4'],
    fingering: [1, 2, 3, 5, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 70,
    keySignature: 'Accordo DO Magg (C)',
    tips: [
      'Mantieni il polso morbido mentre la mano si apre leggermente per raggiungere il Do5 con il mignolo (5).',
    ],
  },
  {
    id: 'arpeggio_a_minor',
    name: 'Arpeggio di LA Minore (A Minor Triad)',
    category: 'Arpeggi',
    description: 'Arpeggio sulla triade di La Minore (La - Do - Mi - La). Grande espressività ed eleganza pianistica.',
    notes: ['A3', 'C4', 'E4', 'A4', 'E4', 'C4', 'A3'],
    fingering: [1, 2, 3, 5, 3, 2, 1],
    difficulty: 'Facile',
    hand: 'right',
    tempoBpm: 70,
    keySignature: 'Accordo LA Min (Am)',
    tips: [
      'Tieni le dita elastiche e fai risuonare la triade con chiarezza.',
    ],
  },
  {
    id: 'scale_c_blues',
    name: 'Scala Blues di DO (C Blues Scale)',
    category: 'Blues & Pentatoniche',
    description: 'La mitica Blue Note (Fa♯/Sol♭) per improvvisare swing, jazz e blues autentico.',
    notes: ['C4', 'Eb4', 'F4', 'F#4', 'G4', 'Bb4', 'C5', 'Bb4', 'G4', 'F#4', 'F4', 'Eb4', 'C4'],
    fingering: [1, 2, 3, 4, 1, 3, 4, 3, 1, 4, 3, 2, 1],
    difficulty: 'Avanzato',
    hand: 'right',
    tempoBpm: 80,
    keySignature: 'Blues DO (E♭, F♯, B♭)',
    tips: [
      'Ottima per il feeling blues: il Fa♯ è la blue note di passaggio.',
    ],
  },
];
