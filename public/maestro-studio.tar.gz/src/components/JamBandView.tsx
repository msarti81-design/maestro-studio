import React, { useState, useEffect, useRef } from 'react';
import { JamStyle, InstrumentType } from '../types';
import { audioEngine } from '../utils/audioEngine';
import { PRESET_SONGS } from '../data/songs';
import { getPublishedSongs, getLocalSongs } from '../utils/songStorage';
import {
  Play,
  Square,
  Sliders,
  Radio,
  Plus,
  Trash2,
  RefreshCw,
  Sparkles,
  BookOpen,
  ArrowRightLeft,
  Volume2,
  ChevronRight,
  Disc,
  Music,
  Edit2,
  Check,
  Zap,
} from 'lucide-react';

// NOTE VALUE & CHORD MAP ENGINE
const NOTE_VALS: Record<string, number> = {
  'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3, 'E': 4, 'F': 5, 'F#': 6, 'Gb': 6,
  'G': 7, 'G#': 8, 'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11,
};
const VAL_TO_NOTE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

export function parseChordToNotes(chordStr: string, baseOctave = 4): string[] {
  if (!chordStr || !chordStr.trim()) return ['C4', 'E4', 'G4'];
  let clean = chordStr.trim().replace(/\s+/g, '');

  let root = 'C';
  let quality = '';
  if (clean.length >= 2 && (clean[1] === '#' || clean[1] === 'b')) {
    root = clean.substring(0, 2);
    quality = clean.substring(2);
  } else {
    root = clean.substring(0, 1);
    quality = clean.substring(1);
  }

  if (root === 'Db') root = 'C#';
  if (root === 'Eb') root = 'D#';
  if (root === 'Gb') root = 'F#';
  if (root === 'Ab') root = 'G#';
  if (root === 'Bb') root = 'A#';

  const rootVal = NOTE_VALS[root] ?? 0;
  let intervals = [0, 4, 7];

  const q = quality.toLowerCase();
  if (q === 'm' || q === 'min' || q.startsWith('m7') || q.startsWith('min7') || q.startsWith('m9')) {
    intervals = [0, 3, 7];
    if (q.includes('7')) intervals.push(10);
    if (q.includes('9')) intervals.push(14);
  } else if (q === 'maj7' || q === 'm7+' || q === 'M7') {
    intervals = [0, 4, 7, 11];
  } else if (q === '7' || q === 'dom7' || q === '7alt' || q === '7b9') {
    intervals = [0, 4, 7, 10];
  } else if (q === 'dim' || q === 'dim7' || q === '°') {
    intervals = [0, 3, 6, 9];
  } else if (q === 'aug' || q === '+') {
    intervals = [0, 4, 8];
  } else if (q === 'sus4' || q === '4') {
    intervals = [0, 5, 7];
  } else if (q === 'sus2' || q === '2') {
    intervals = [0, 2, 7];
  } else if (q === 'add9' || q === '9') {
    intervals = [0, 4, 7, 14];
  } else if (q === 'm6' || q === 'min6') {
    intervals = [0, 3, 7, 9];
  } else if (q === '6') {
    intervals = [0, 4, 7, 9];
  }

  return intervals.map((semitones) => {
    const totalVal = rootVal + semitones;
    const octOffset = Math.floor(totalVal / 12);
    const noteIdx = totalVal % 12;
    return `${VAL_TO_NOTE[noteIdx]}${baseOctave + octOffset}`;
  });
}

export function transposeChord(chordStr: string, semitones: number): string {
  if (!chordStr || !chordStr.trim()) return 'C';
  let clean = chordStr.trim().replace(/\s+/g, '');
  let root = 'C';
  let quality = '';
  if (clean.length >= 2 && (clean[1] === '#' || clean[1] === 'b')) {
    root = clean.substring(0, 2);
    quality = clean.substring(2);
  } else {
    root = clean.substring(0, 1);
    quality = clean.substring(1);
  }

  if (root === 'Db') root = 'C#';
  if (root === 'Eb') root = 'D#';
  if (root === 'Gb') root = 'F#';
  if (root === 'Ab') root = 'G#';
  if (root === 'Bb') root = 'A#';

  const rootVal = NOTE_VALS[root] ?? 0;
  let newVal = (rootVal + semitones) % 12;
  if (newVal < 0) newVal += 12;

  return `${VAL_TO_NOTE[newVal]}${quality}`;
}

// STYLES CONFIGURATION
const JAM_STYLES: { id: JamStyle; name: string; description: string; defaultBpm: number; defaultChords: string[] }[] = [
  { id: 'jazz', name: 'Jazz Swing', description: 'Basso walking swing, spazzole di batteria e accordi jazz.', defaultBpm: 120, defaultChords: ['Dm7', 'G7', 'Cmaj7', 'A7'] },
  { id: 'rock', name: 'Rock Groove', description: 'Chitarra ritmica, basso elettrico e cassa/rullante dritto.', defaultBpm: 130, defaultChords: ['G', 'D', 'Em', 'C'] },
  { id: 'pop', name: 'Acoustic Pop', description: 'Accordi caldi di chitarra/piano con ritmo pop trascinante.', defaultBpm: 115, defaultChords: ['C', 'G', 'Am', 'F'] },
  { id: 'lofi', name: 'Lo-Fi Chill', description: 'Ritmo rilassato, sub bass profondo e accordi estesi.', defaultBpm: 85, defaultChords: ['Dm9', 'G13', 'Cmaj7', 'A7'] },
  { id: 'blues', name: 'Blues Shuffle', description: 'Struttura 12-bar blues shuffle con basso in movimento.', defaultBpm: 110, defaultChords: ['C7', 'C7', 'C7', 'C7', 'F7', 'F7', 'C7', 'C7', 'G7', 'F7', 'C7', 'G7'] },
  { id: 'bossa', name: 'Bossa Nova', description: 'Sincopato brasiliano con chitarra classica e percussioni.', defaultBpm: 125, defaultChords: ['Dm7', 'G7', 'Cmaj7', 'Cmaj7'] },
];

// PRESET CHORD PROGRESSIONS
const PROGRESSION_PRESETS = [
  { name: 'Pop Hit (1 - 5 - 6 - 4)', chords: ['C', 'G', 'Am', 'F'] },
  { name: 'Sensitive Pop (6 - 4 - 1 - 5)', chords: ['Am', 'F', 'C', 'G'] },
  { name: 'Jazz Standard (2 - 5 - 1 - 6)', chords: ['Dm7', 'G7', 'Cmaj7', 'A7'] },
  { name: '12-Bar Blues Classico', chords: ['C7', 'C7', 'C7', 'C7', 'F7', 'F7', 'C7', 'C7', 'G7', 'F7', 'C7', 'G7'] },
  { name: 'Canone di Pachelbel', chords: ['C', 'G', 'Am', 'Em', 'F', 'C', 'F', 'G'] },
  { name: 'Cadenza Andalusa (Flamenco)', chords: ['Am', 'G', 'F', 'E7'] },
  { name: 'Bossa Nova Sunset', chords: ['Dm7', 'G7', 'Cmaj7', 'Cmaj7', 'Fm7', 'Bb7', 'Ebmaj7', 'Ebmaj7'] },
  { name: 'R&B / Soul Stiff', chords: ['C', 'E7', 'F', 'Fm'] },
  { name: 'Doo-Wop Anni 50 (1 - 6 - 4 - 5)', chords: ['C', 'Am', 'F', 'G'] },
  { name: 'Lo-Fi Chill Sunset', chords: ['Dm9', 'G13', 'Cmaj7', 'A7'] },
  { name: 'Rock Ballad (1 - b7 - 4)', chords: ['A', 'G', 'D', 'A'] },
  { name: 'Epic Movie Theme', chords: ['Am', 'F', 'Dm', 'E7'] },
];

// CHORD SELECTION PALETTE
const CHORD_PALETTE_ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const CHORD_PALETTE_QUALITIES = ['', 'm', '7', 'maj7', 'm7', 'dim', 'sus4', 'add9', '6'];

export const JamBandView: React.FC = () => {
  const [selectedStyle, setSelectedStyle] = useState<JamStyle>('jazz');
  const [bpm, setBpm] = useState<number>(120);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentBar, setCurrentBar] = useState<number>(0);

  // Active Chord Progression Loop (User Editable!)
  const [chords, setChords] = useState<string[]>(['Dm7', 'G7', 'Cmaj7', 'A7']);

  // Editing state
  const [editingBarIndex, setEditingBarIndex] = useState<number | null>(null);
  const [customInputChord, setCustomInputChord] = useState<string>('');

  // Selected Key & Transposition
  const [currentKeyRoot, setCurrentKeyRoot] = useState<string>('C');

  // Instrument toggles
  const [activeInstruments, setActiveInstruments] = useState<Record<InstrumentType | 'drums', boolean>>({
    drums: true,
    bass: true,
    guitar: true,
    piano: true,
    strings: false,
    synth: false,
  });

  // Tap Tempo state
  const lastTapRef = useRef<number>(0);

  // Sync style defaults
  useEffect(() => {
    const s = JAM_STYLES.find((item) => item.id === selectedStyle);
    if (s) {
      setBpm(s.defaultBpm);
    }
  }, [selectedStyle]);

  // Main Jam Playback Loop
  useEffect(() => {
    if (!isPlaying) return;

    const barSeconds = (60 / bpm) * 2; // 2 beats per measure
    const intervalMs = barSeconds * 1000;

    let barIdx = 0;

    const timer = setInterval(() => {
      barIdx = (barIdx + 1) % chords.length;
      setCurrentBar(barIdx);
      playJamBar(chords[barIdx]);
    }, intervalMs);

    // Play first measure immediately
    setCurrentBar(0);
    playJamBar(chords[0]);

    return () => clearInterval(timer);
  }, [isPlaying, bpm, chords]);

  const playJamBar = async (chordName: string) => {
    const chordNotes = parseChordToNotes(chordName, 4);
    const rootNote = chordNotes[0].replace('4', '2').replace('3', '2').replace('5', '2');

    // 1. Drums
    if (activeInstruments.drums) {
      audioEngine.playDrum('kick', 0);
      audioEngine.playDrum('hihat', 0.2);
      audioEngine.playDrum('snare', 0.4);
      audioEngine.playDrum('hihat', 0.6);
    }

    // 2. Bass
    if (activeInstruments.bass) {
      audioEngine.playNote(rootNote, '2n', 'bass');
    }

    // 3. Guitar / Piano / Strings
    if (activeInstruments.guitar) {
      audioEngine.playChord(chordNotes, '2n', 'guitar');
    }
    if (activeInstruments.piano) {
      audioEngine.playChord(chordNotes, '2n', 'piano');
    }
    if (activeInstruments.strings) {
      audioEngine.playChord(chordNotes, '1n', 'strings');
    }
  };

  const toggleInstrument = (inst: InstrumentType | 'drums') => {
    setActiveInstruments((prev) => ({ ...prev, [inst]: !prev[inst] }));
  };

  // Modify chord at specific bar
  const handleUpdateBarChord = (index: number, newChord: string) => {
    if (!newChord.trim()) return;
    const clean = newChord.trim();
    const updated = [...chords];
    updated[index] = clean;
    setChords(updated);
    setEditingBarIndex(null);
  };

  // Add new measure bar
  const handleAddBar = () => {
    if (chords.length >= 16) return;
    const lastChord = chords[chords.length - 1] || 'C';
    setChords([...chords, lastChord]);
  };

  // Remove measure bar
  const handleRemoveBar = (index: number) => {
    if (chords.length <= 1) return;
    const updated = chords.filter((_, i) => i !== index);
    setChords(updated);
    if (currentBar >= updated.length) {
      setCurrentBar(0);
    }
  };

  // Transpose whole progression
  const handleTranspose = (semitones: number) => {
    const updated = chords.map((c) => transposeChord(c, semitones));
    setChords(updated);
  };

  // Load Preset Progression
  const handleSelectPresetProgression = (presetChords: string[]) => {
    setChords([...presetChords]);
    setCurrentBar(0);
  };

  // Load Chord Sequence from Song Library
  const handleImportSongChords = (songChords: string[]) => {
    if (!songChords || songChords.length === 0) return;
    setChords([...songChords]);
    setCurrentBar(0);
  };

  // Tap Tempo Handler
  const handleTapTempo = () => {
    const now = Date.now();
    if (lastTapRef.current > 0) {
      const diffSec = (now - lastTapRef.current) / 1000;
      if (diffSec > 0.25 && diffSec < 2.0) {
        const calculatedBpm = Math.round(60 / diffSec);
        setBpm(Math.max(60, Math.min(200, calculatedBpm)));
      }
    }
    lastTapRef.current = now;
  };

  const currentChordNotes = parseChordToNotes(chords[currentBar] || 'C', 4);

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6 select-none pb-12">
      {/* HEADER & MAIN TRANSPORT CONTROLS */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 sm:p-6 rounded-3xl shadow-xl flex flex-col lg:flex-row items-center justify-between gap-5">
        <div className="space-y-1 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[10px] font-black uppercase tracking-widest">
            <Radio className="w-3.5 h-3.5" />
            <span>Jam Band Accompaniment Studio</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center justify-center lg:justify-start gap-2">
            <span>Accompagnamento & Progressioni Personalizzabili</span>
            <Sparkles className="w-5 h-5 text-amber-400" />
          </h1>
          <p className="text-slate-400 text-xs max-w-xl">
            Modifica gli accordi battuta per battuta, importa brani dalla libreria, trasponi la tonalit&agrave; e suona in tempo reale col tuo pianoforte!
          </p>
        </div>

        {/* Transport & BPM Box */}
        <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
          {/* BPM & TAP TEMPO */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-2xl border border-slate-800">
            <span className="text-xs font-bold text-slate-400 uppercase">BPM:</span>
            <input
              type="number"
              min="60"
              max="200"
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="w-14 bg-slate-900 text-amber-300 text-center text-sm font-black rounded-lg px-1 outline-none border border-slate-700"
            />
            <button
              onClick={handleTapTempo}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-bold uppercase transition-all active:scale-95 cursor-pointer"
              title="Clicca a tempo per impostare i BPM automaticamente"
            >
              TAP 👆
            </button>
          </div>

          {/* PLAY / STOP BUTTON */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-6 py-3 text-xs sm:text-sm font-black rounded-2xl flex items-center gap-2.5 transition-all shadow-xl active:scale-95 cursor-pointer ${
              isPlaying
                ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 hover:from-amber-400 hover:to-yellow-300 shadow-amber-500/20'
            }`}
          >
            {isPlaying ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isPlaying ? 'FERMA JAM SESSION' : 'AVVIA JAM BAND'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: INTERACTIVE CHORD PROGRESSION EDITOR */}
      <div className="bg-slate-900/95 border border-slate-800 p-5 sm:p-6 rounded-3xl space-y-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <Disc className="w-5 h-5 text-amber-400" />
              <span>Giro di Accordi in Loop ({chords.length} Battute)</span>
            </h2>
            <p className="text-slate-400 text-xs">
              Clicca su qualsiasi battuta per cambiare l'accordo, aggiungi o rimuovi battute per creare il tuo brano!
            </p>
          </div>

          {/* TRANSPOSITION & EDIT ACTIONS */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="text-[10px] text-slate-400 font-bold uppercase mr-1">Trasponi:</div>
            <button
              onClick={() => handleTranspose(-1)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg text-xs font-black border border-slate-700 active:scale-95 cursor-pointer"
              title="Trasponi di -1 semitono"
            >
              -1 Semitono
            </button>
            <button
              onClick={() => handleTranspose(1)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg text-xs font-black border border-slate-700 active:scale-95 cursor-pointer"
              title="Trasponi di +1 semitono"
            >
              +1 Semitono
            </button>
          </div>
        </div>

        {/* MEASURE BARS GRID */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {chords.map((chord, idx) => {
            const isCurrent = isPlaying && currentBar === idx;
            const isEditing = editingBarIndex === idx;

            return (
              <div
                key={idx}
                className={`relative p-3.5 rounded-2xl border flex flex-col items-center justify-between gap-2 transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-b from-amber-500 to-yellow-400 text-slate-950 border-amber-300 shadow-2xl scale-105 z-10'
                    : 'bg-slate-950 border-slate-800 hover:border-amber-500/50 text-white'
                }`}
              >
                {/* Bar Number */}
                <div className="flex items-center justify-between w-full">
                  <span
                    className={`text-[9px] font-black uppercase tracking-wider ${
                      isCurrent ? 'text-slate-900' : 'text-slate-400'
                    }`}
                  >
                    Battuta {idx + 1}
                  </span>

                  {/* Remove Bar Button */}
                  {chords.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveBar(idx);
                      }}
                      className={`text-[10px] opacity-60 hover:opacity-100 p-0.5 rounded ${
                        isCurrent ? 'hover:bg-slate-900/20 text-slate-950' : 'hover:bg-red-500/20 text-red-400'
                      }`}
                      title="Elimina questa battuta"
                    >
                      ✖
                    </button>
                  )}
                </div>

                {/* Chord Value or Edit Input */}
                {isEditing ? (
                  <div className="w-full space-y-1 my-1">
                    <input
                      type="text"
                      value={customInputChord}
                      onChange={(e) => setCustomInputChord(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleUpdateBarChord(idx, customInputChord);
                      }}
                      className="w-full bg-slate-900 text-amber-300 text-center font-black text-sm p-1 rounded border border-amber-400 outline-none"
                      autoFocus
                    />
                    <button
                      onClick={() => handleUpdateBarChord(idx, customInputChord)}
                      className="w-full py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded"
                    >
                      OK ✓
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => {
                      setEditingBarIndex(idx);
                      setCustomInputChord(chord);
                    }}
                    className="cursor-pointer group flex flex-col items-center my-1"
                    title="Clicca per modificare l'accordo di questa battuta"
                  >
                    <div className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-1">
                      <span>{chord}</span>
                      <Edit2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                )}

                {/* Active Indicator Bar */}
                <div
                  className={`w-full h-1 rounded-full ${
                    isCurrent ? 'bg-slate-950' : 'bg-slate-800'
                  }`}
                />
              </div>
            );
          })}

          {/* ADD MEASURE BUTTON */}
          {chords.length < 16 && (
            <button
              onClick={handleAddBar}
              className="p-3.5 rounded-2xl border border-dashed border-slate-700 hover:border-amber-400 bg-slate-950/50 hover:bg-slate-900 text-slate-400 hover:text-amber-300 flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all cursor-pointer active:scale-95"
              title="Aggiungi una nuova battuta al giro"
            >
              <Plus className="w-5 h-5 text-amber-400" />
              <span>+ Battuta</span>
            </button>
          )}
        </div>

        {/* QUICK CHORD PALETTE SELECTOR (When Editing a Bar) */}
        {editingBarIndex !== null && (
          <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/40 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between text-xs text-amber-300 font-bold">
              <span>Seleziona Accordo Rapido per Battuta {editingBarIndex + 1}:</span>
              <button
                onClick={() => setEditingBarIndex(null)}
                className="text-slate-400 hover:text-white text-[10px] bg-slate-900 px-2 py-0.5 rounded border border-slate-800"
              >
                Chiudi ✖
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-1">
                <span className="text-[10px] text-slate-400 font-bold w-12 shrink-0">Nota:</span>
                {CHORD_PALETTE_ROOTS.map((root) => (
                  <button
                    key={root}
                    onClick={() => {
                      const currentQual = customInputChord.replace(/^[A-G][#b]?/, '');
                      setCustomInputChord(`${root}${currentQual}`);
                    }}
                    className="px-2 py-1 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-slate-200 rounded font-black text-xs border border-slate-800"
                  >
                    {root}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-1">
                <span className="text-[10px] text-slate-400 font-bold w-12 shrink-0">Tipo:</span>
                {CHORD_PALETTE_QUALITIES.map((q) => {
                  const rootPart = customInputChord.match(/^[A-G][#b]?/)?.[0] || 'C';
                  const candidate = `${rootPart}${q}`;
                  return (
                    <button
                      key={q || 'major'}
                      onClick={() => {
                        handleUpdateBarChord(editingBarIndex, candidate);
                      }}
                      className="px-2 py-1 bg-slate-800 hover:bg-amber-400 text-amber-300 hover:text-slate-950 rounded font-bold text-xs border border-slate-700"
                    >
                      {candidate}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: IMPORT BRANI DALLA LIBRERIA & PRESET GIRO ACCORDI */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* PRESET PROGRESSION SELECTOR */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl space-y-3 shadow-xl">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Scegli una Progressioni Preset Famosa</span>
          </h3>
          <p className="text-slate-400 text-xs">
            Seleziona un giro di accordi celebre per caricare subito la struttura nel loop:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
            {PROGRESSION_PRESETS.map((p, pIdx) => (
              <button
                key={pIdx}
                onClick={() => handleSelectPresetProgression(p.chords)}
                className="p-2.5 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/50 rounded-xl text-left transition-all group cursor-pointer"
              >
                <div className="text-xs font-bold text-white group-hover:text-amber-300">{p.name}</div>
                <div className="text-[10px] font-mono text-slate-400 truncate mt-0.5">
                  {p.chords.join(' - ')}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* IMPORT FROM SONG LIBRARY */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl space-y-3 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Carica Accordi da un Brano della Libreria</span>
            </h3>
            <p className="text-slate-400 text-xs">
              Importa la sequenza armonica dei brani o degli spartiti salvati per esercitarti in jam band:
            </p>
          </div>

          <div className="space-y-2">
            <select
              onChange={(e) => {
                const songId = e.target.value;
                if (!songId) return;
                const foundPreset = PRESET_SONGS.find((s) => s.id === songId);
                if (foundPreset && foundPreset.chords) {
                  handleImportSongChords(foundPreset.chords);
                }
              }}
              className="w-full bg-slate-950 text-amber-300 text-xs font-bold border border-slate-800 p-3 rounded-xl outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="">-- Seleziona un brano dalla Libreria --</option>
              {PRESET_SONGS.map((song) => (
                <option key={song.id} value={song.id}>
                  🎵 {song.title} ({song.key}) - [{song.chords.join(' - ')}]
                </option>
              ))}
            </select>
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800/80 flex items-center gap-2">
            <span>💡</span>
            <span>La Jam Band riprodurr&agrave; le batterie, il basso e gli strumenti d'accompagnamento sui tuoi accordi!</span>
          </div>
        </div>
      </div>

      {/* SECTION 3: STILI MUSICALI & MIXER STRUMENTI VIRTUALI */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* JAM STYLE PRESETS */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 p-5 sm:p-6 rounded-3xl space-y-4 shadow-xl">
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-amber-400" />
            <span>Stile del Ritmo e dell'Accompagnamento</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {JAM_STYLES.map((style) => {
              const isSelected = selectedStyle === style.id;
              return (
                <div
                  key={style.id}
                  onClick={() => setSelectedStyle(style.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-gradient-to-b from-amber-500/20 to-yellow-500/10 border-amber-400 text-white shadow-lg'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-black text-white">{style.name}</h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-amber-400">
                      {style.defaultBpm} BPM
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">{style.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* VIRTUAL BAND MIXER */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 sm:p-6 rounded-3xl space-y-4 shadow-xl">
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Mixer Componenti della Band</span>
          </h3>

          <div className="space-y-2">
            {[
              { id: 'drums', label: '🥁 Batteria & Percussioni' },
              { id: 'bass', label: '🎸 Basso Elettrico / Contrabbasso' },
              { id: 'guitar', label: '🪕 Chitarra Ritmica' },
              { id: 'piano', label: '🎹 Pianoforte d\'Accompagnamento' },
              { id: 'strings', label: '🎻 Archi e Tappeto Armonico' },
            ].map((item) => {
              const key = item.id as InstrumentType | 'drums';
              const isActive = activeInstruments[key];

              return (
                <div
                  key={item.id}
                  onClick={() => toggleInstrument(key)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    isActive
                      ? 'bg-slate-800 border-amber-500/60 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-500'
                  }`}
                >
                  <span className="text-xs font-bold">{item.label}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-black uppercase ${
                      isActive ? 'bg-amber-400 text-slate-950' : 'bg-slate-900 text-slate-500'
                    }`}
                  >
                    {isActive ? 'ON 🔊' : 'MUTATO 🔇'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
