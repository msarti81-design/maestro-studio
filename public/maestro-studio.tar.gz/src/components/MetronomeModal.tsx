import React, { useState, useEffect, useRef } from 'react';
import { audioEngine } from '../utils/audioEngine';
import { pitchDetector } from '../utils/pitchDetector';
import {
  Timer,
  Play,
  Square,
  Volume2,
  X,
  Sparkles,
  Zap,
  Music,
  Activity,
  Sliders,
  HelpCircle,
  Mic,
  MicOff,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';

interface MetronomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBpmChange?: (bpm: number) => void;
}

const TEMPO_PRESETS = [
  { name: 'Grave', bpm: 44, desc: 'Lentissimo e solenne' },
  { name: 'Largo', bpm: 56, desc: 'Lento e maestoso' },
  { name: 'Adagio', bpm: 68, desc: 'Lento ed espressivo' },
  { name: 'Andante', bpm: 88, desc: 'Passo naturale (Camminando)' },
  { name: 'Moderato', bpm: 112, desc: 'Velocità moderata' },
  { name: 'Allegro', bpm: 132, desc: 'Veloce e brillante' },
  { name: 'Presto', bpm: 168, desc: 'Molto veloce e rapido' },
  { name: 'Prestissimo', bpm: 200, desc: 'Massima velocità' },
];

const TIME_SIGNATURES = [
  { label: '2/4', beats: 2, name: 'Marcia' },
  { label: '3/4', beats: 3, name: 'Valzer' },
  { label: '4/4', beats: 4, name: 'Tempo Ordinario' },
  { label: '6/8', beats: 6, name: 'Barcarola / Pastorale' },
];

export const MetronomeModal: React.FC<MetronomeModalProps> = ({
  isOpen,
  onClose,
  onBpmChange,
}) => {
  const [activeTab, setActiveTab] = useState<'metronome' | 'chords' | 'tuner'>('metronome');

  // Metronome State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [bpm, setBpm] = useState<number>(100);
  const [timeSignature, setTimeSignature] = useState<number>(4);
  const [accentFirstBeat, setAccentFirstBeat] = useState<boolean>(true);
  const [currentBeat, setCurrentBeat] = useState<number>(0);

  // Tap Tempo State
  const tapTimesRef = useRef<number[]>([]);
  const [tapMessage, setTapMessage] = useState<string | null>(null);

  // Interval timer ref
  const metronomeTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Tuner State
  const [isTunerActive, setIsTunerActive] = useState<boolean>(false);
  const [tunerNote, setTunerNote] = useState<string | null>(null);
  const [tunerCents, setTunerCents] = useState<number>(0);
  const [tunerFreq, setTunerFreq] = useState<number>(0);

  useEffect(() => {
    if (isPlaying) {
      startMetronomeTimer();
    } else {
      stopMetronomeTimer();
    }
    return () => stopMetronomeTimer();
  }, [isPlaying, bpm, timeSignature, accentFirstBeat]);

  const stopMetronomeTimer = () => {
    if (metronomeTimerRef.current) {
      clearInterval(metronomeTimerRef.current);
      metronomeTimerRef.current = null;
    }
  };

  const startMetronomeTimer = () => {
    stopMetronomeTimer();
    audioEngine.init().catch(() => {});

    let beat = 0;
    const intervalMs = (60 / bpm) * 1000;

    // Trigger immediate first beat click
    const isAccent = accentFirstBeat && beat === 0;
    audioEngine.playMetronomeClick(isAccent);
    setCurrentBeat(beat);

    beat = (beat + 1) % timeSignature;

    metronomeTimerRef.current = setInterval(() => {
      const isAccentNow = accentFirstBeat && beat === 0;
      audioEngine.playMetronomeClick(isAccentNow);
      setCurrentBeat(beat);
      beat = (beat + 1) % timeSignature;
    }, intervalMs);
  };

  const handleBpmUpdate = (newBpm: number) => {
    const clamped = Math.min(260, Math.max(30, newBpm));
    setBpm(clamped);
    if (onBpmChange) onBpmChange(clamped);
  };

  const handleTapTempo = () => {
    const now = Date.now();
    const times = tapTimesRef.current;

    // Reset if last tap was more than 2.5 seconds ago
    if (times.length > 0 && now - times[times.length - 1] > 2500) {
      tapTimesRef.current = [now];
      setTapMessage('Rilevamento Tap...');
      return;
    }

    times.push(now);
    if (times.length > 5) times.shift();

    if (times.length >= 2) {
      const intervals = [];
      for (let i = 1; i < times.length; i++) {
        intervals.push(times[i] - times[i - 1]);
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const calculatedBpm = Math.round(60000 / avgInterval);
      if (calculatedBpm >= 30 && calculatedBpm <= 260) {
        handleBpmUpdate(calculatedBpm);
        setTapMessage(`TAP: ${calculatedBpm} BPM`);
      }
    } else {
      setTapMessage('Batti di nuovo il ritmo...');
    }
  };

  // Live Tuner Logic
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;
    if (isTunerActive && activeTab === 'tuner') {
      if (pitchDetector && typeof pitchDetector.startListening === 'function') {
        pitchDetector.startListening().then((success) => {
          if (success && pitchDetector && typeof pitchDetector.subscribe === 'function') {
            unsubscribe = pitchDetector.subscribe((res) => {
              if (res && res.note) {
                setTunerNote(res.note);
                setTunerCents(res.cents || 0);
                setTunerFreq(res.frequency || 0);
              }
            });
          } else {
            alert('Impossibile accedere al microfono per l’accordatore.');
            setIsTunerActive(false);
          }
        });
      }
    } else {
      if (pitchDetector && typeof pitchDetector.stopListening === 'function') {
        pitchDetector.stopListening();
      } else if (pitchDetector && typeof pitchDetector.stop === 'function') {
        pitchDetector.stop();
      }
    }

    return () => {
      if (unsubscribe) unsubscribe();
      if (pitchDetector && typeof pitchDetector.stopListening === 'function') {
        pitchDetector.stopListening();
      } else if (pitchDetector && typeof pitchDetector.stop === 'function') {
        pitchDetector.stop();
      }
    };
  }, [isTunerActive, activeTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-amber-500/40 w-full max-w-xl rounded-3xl p-6 space-y-6 shadow-2xl relative animate-fadeIn select-none">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 to-yellow-400 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Timer className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                Metronomo & Strumenti da Studio
              </h2>
              <p className="text-slate-400 text-xs">
                Mantenimento del tempo, analisi accordi e accordatore integrato
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsPlaying(false);
              setIsTunerActive(false);
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Studio Sub-Navigation Tabs */}
        <div className="flex items-center bg-slate-950 p-1 rounded-2xl border border-slate-800 gap-1">
          <button
            onClick={() => setActiveTab('metronome')}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'metronome'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Timer className="w-4 h-4" />
            <span>Metronomo</span>
          </button>

          <button
            onClick={() => setActiveTab('chords')}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'chords'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Music className="w-4 h-4" />
            <span>Prontuario Accordi</span>
          </button>

          <button
            onClick={() => setActiveTab('tuner')}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'tuner'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Accordatore</span>
          </button>
        </div>

        {/* TAB 1: METRONOME */}
        {activeTab === 'metronome' && (
          <div className="space-y-6">
            {/* BIG BPM DISPLAY & VISUAL BEATS */}
            <div className="bg-slate-950/80 border border-amber-500/30 p-6 rounded-3xl text-center space-y-4 shadow-inner relative overflow-hidden">
              {/* Visual Beating LED Lights */}
              <div className="flex items-center justify-center gap-3">
                {Array.from({ length: timeSignature }).map((_, idx) => {
                  const isActive = isPlaying && currentBeat === idx;
                  const isAccent = accentFirstBeat && idx === 0;

                  return (
                    <div
                      key={idx}
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center text-xs font-black transition-all duration-100 border ${
                        isActive
                          ? isAccent
                            ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 border-amber-300 scale-110 shadow-lg shadow-amber-500/40 ring-4 ring-amber-400/30'
                            : 'bg-emerald-500 text-slate-950 border-emerald-300 scale-105 shadow-md shadow-emerald-500/30'
                          : 'bg-slate-900 text-slate-500 border-slate-800'
                      }`}
                    >
                      <span>{idx + 1}</span>
                    </div>
                  );
                })}
              </div>

              {/* BPM Large Counter */}
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400 tracking-tight">
                  {bpm}
                </span>
                <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">
                  BPM
                </span>
              </div>

              {/* Tap Tempo Feedback */}
              {tapMessage && (
                <div className="text-[11px] font-bold text-amber-300 bg-amber-500/10 px-3 py-1 rounded-full inline-block border border-amber-500/20">
                  {tapMessage}
                </div>
              )}

              {/* Start / Stop Toggle */}
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`px-8 py-3.5 rounded-2xl font-black text-sm flex items-center gap-2 transition-all shadow-xl active:scale-95 cursor-pointer ${
                    isPlaying
                      ? 'bg-red-500 hover:bg-red-400 text-white shadow-red-500/20 animate-pulse'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-amber-500/20 hover:from-amber-400 hover:to-yellow-300'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Square className="w-5 h-5 fill-current" />
                      <span>Ferma Metronomo</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      <span>Avvia Metronomo</span>
                    </>
                  )}
                </button>

                {/* TAP TEMPO BUTTON */}
                <button
                  onClick={handleTapTempo}
                  className="px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-black text-xs rounded-2xl active:scale-95 cursor-pointer transition-all shadow-md"
                  title="Tocca il pulsante a tempo di musica per impostare automaticamente il BPM"
                >
                  <span>👆 TAP TEMPO</span>
                </button>
              </div>
            </div>

            {/* CONTROLS GRID */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* BPM Slider & Steppers */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">Regola Velocità (BPM)</label>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleBpmUpdate(bpm - 1)}
                      className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-bold text-xs flex items-center justify-center"
                    >
                      -
                    </button>
                    <button
                      onClick={() => handleBpmUpdate(bpm + 1)}
                      className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-bold text-xs flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                </div>

                <input
                  type="range"
                  min="30"
                  max="260"
                  value={bpm}
                  onChange={(e) => handleBpmUpdate(Number(e.target.value))}
                  className="w-full h-2 accent-amber-500 bg-slate-800 rounded-lg cursor-pointer"
                />

                {/* Presets dropdown */}
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) handleBpmUpdate(Number(e.target.value));
                  }}
                  className="w-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-bold p-2 rounded-xl outline-none"
                >
                  <option value="">-- Seleziona Tempo Classico --</option>
                  {TEMPO_PRESETS.map((p) => (
                    <option key={p.name} value={p.bpm}>
                      {p.name} ({p.bpm} BPM) - {p.desc}
                    </option>
                  ))}
                </select>
              </div>

              {/* Time Signature & Accents */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-slate-300 block">Tempo / Frazione</label>
                <div className="grid grid-cols-2 gap-2">
                  {TIME_SIGNATURES.map((ts) => (
                    <button
                      key={ts.label}
                      onClick={() => setTimeSignature(ts.beats)}
                      className={`p-2 rounded-xl text-xs font-bold border transition-all ${
                        timeSignature === ts.beats
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="font-black text-sm">{ts.label}</div>
                      <div className="text-[9px] opacity-70">{ts.name}</div>
                    </button>
                  ))}
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={accentFirstBeat}
                    onChange={(e) => setAccentFirstBeat(e.target.checked)}
                    className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                  />
                  <span className="text-xs font-bold text-slate-300">
                    Accento acuto sul primo battito (1)
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRONTUARIO ACCORDI */}
        {activeTab === 'chords' && (
          <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Music className="w-4 h-4" />
                <span>Principali Accordi di Pianoforte</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-black text-white">Do Maggiore (C)</div>
                  <div className="text-amber-300 font-mono font-bold">C4 - E4 - G4</div>
                  <div className="text-[10px] text-slate-400">Fondamentale, Terza Maggiore, Quinta Giusta</div>
                </div>

                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-black text-white">La Minore (Am)</div>
                  <div className="text-amber-300 font-mono font-bold">A3 - C4 - E4</div>
                  <div className="text-[10px] text-slate-400">Fondamentale, Terza Minore, Quinta Giusta</div>
                </div>

                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-black text-white">Fa Maggiore (F)</div>
                  <div className="text-amber-300 font-mono font-bold">F3 - A3 - C4</div>
                  <div className="text-[10px] text-slate-400">Fondamentale, Terza Maggiore, Quinta Giusta</div>
                </div>

                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-black text-white">Sol Maggiore 7 (G7)</div>
                  <div className="text-amber-300 font-mono font-bold">G3 - B3 - D4 - F4</div>
                  <div className="text-[10px] text-slate-400">Accordo di Settima Domiante</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ACCORDATORE PITCH DETECTOR */}
        {activeTab === 'tuner' && (
          <div className="space-y-4 text-center">
            <div className="bg-slate-950 p-6 rounded-3xl border border-amber-500/30 space-y-4">
              <button
                onClick={() => setIsTunerActive(!isTunerActive)}
                className={`px-6 py-3 rounded-2xl font-black text-xs flex items-center justify-center gap-2 mx-auto cursor-pointer ${
                  isTunerActive
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                }`}
              >
                {isTunerActive ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    <span>Disattiva Microfono</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>Attiva Microfono & Accordatore</span>
                  </>
                )}
              </button>

              {isTunerActive && (
                <div className="space-y-3 pt-2">
                  <div className="text-4xl font-black text-amber-300">
                    {tunerNote || '--'}
                  </div>
                  <div className="text-xs text-slate-400 font-mono">
                    Frequenza: {tunerFreq ? `${tunerFreq.toFixed(1)} Hz` : '--'}
                  </div>

                  {/* Tuning gauge */}
                  <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden relative border border-slate-800">
                    <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-amber-400 z-10" />
                    <div
                      className="h-full bg-emerald-400 transition-all duration-100"
                      style={{
                        width: '10px',
                        marginLeft: `${Math.min(95, Math.max(5, 50 + tunerCents))}%`,
                      }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Cents: {tunerCents > 0 ? `+${tunerCents}` : tunerCents}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
