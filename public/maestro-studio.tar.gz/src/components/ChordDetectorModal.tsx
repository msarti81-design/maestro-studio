import React from 'react';
import { X, Music, Sparkles, Layers, BookOpen } from 'lucide-react';
import { identifyChord, IdentifiedChord } from '../utils/chordDetector';

interface ChordDetectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeNotes: string[];
  chordHistory: { chord: IdentifiedChord; time: string }[];
}

export const ChordDetectorModal: React.FC<ChordDetectorModalProps> = ({
  isOpen,
  onClose,
  activeNotes,
  chordHistory,
}) => {
  if (!isOpen) return null;

  const currentChord = identifyChord(activeNotes);

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 animate-in fade-in">
      <div className="bg-slate-900 border-2 border-amber-500/60 rounded-2xl max-w-lg w-full max-h-[85vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-slate-900 via-amber-950/30 to-slate-900 border-b border-amber-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center font-black text-lg shadow-md shadow-amber-500/30">
              🎹
            </div>
            <div>
              <h3 className="text-base font-black text-white">Analizzatore di Accordi in Tempo Reale</h3>
              <p className="text-[11px] text-amber-300/80">
                Riconoscimento armonico istantaneo per tastiera e MIDI
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title="Chiudi"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Active Chord Big Display Card */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-amber-500/40 rounded-2xl p-5 flex flex-col items-center text-center shadow-xl relative overflow-hidden">
            <div className="absolute top-2 right-3 text-[10px] text-amber-400 font-bold uppercase tracking-wider bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              Live Feed
            </div>

            <div className="text-xs text-slate-400 uppercase font-extrabold tracking-widest mb-1">
              Accordo Riconosciuto
            </div>

            {currentChord ? (
              <div className="space-y-1.5 my-2">
                <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-300 font-mono tracking-tight drop-shadow">
                  {currentChord.symbol}
                </div>
                <div className="text-sm font-bold text-amber-300">
                  {currentChord.name}
                </div>
              </div>
            ) : (
              <div className="my-4 text-slate-500 italic text-sm">
                Suona 2 o più tasti sul piano o collega una tastiera MIDI...
              </div>
            )}

            {/* Active Notes Badge List */}
            <div className="mt-3 flex items-center gap-1.5 flex-wrap justify-center">
              <span className="text-[10px] text-slate-400 font-bold">Note attive:</span>
              {activeNotes.length > 0 ? (
                activeNotes.map((n, idx) => (
                  <span
                    key={idx}
                    className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-mono font-bold text-xs"
                  >
                    {n}
                  </span>
                ))
              ) : (
                <span className="text-slate-600 text-xs italic">Nessuna</span>
              )}
            </div>
          </div>

          {/* Chord Progression History */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Progressione Recente</span>
              </span>
              <span className="text-[9px] text-slate-500">Ultimi accordi suonati</span>
            </div>

            {chordHistory.length > 0 ? (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {chordHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 flex flex-col items-center shrink-0 shadow-inner"
                  >
                    <span className="font-mono font-black text-amber-400 text-sm">{item.chord.symbol}</span>
                    <span className="text-[9px] text-slate-400 mt-0.5">{item.time}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-slate-500 italic text-xs">
                La tua progressione armonica apparirà qui man mano che suoni gli accordi.
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs cursor-pointer shadow"
          >
            Chiudi Analizzatore
          </button>
        </div>
      </div>
    </div>
  );
};
