import React, { useState } from 'react';
import { InteractiveSong } from '../types';
import { getAppApiUrl } from '../utils/networkHelper';
import {
  ShieldAlert,
  AlertTriangle,
  Check,
  X,
  Send,
  Lock,
  Mail,
  FileText,
  Flag,
  Globe,
} from 'lucide-react';

// ============================================================================
// 1. PUBLISH DISCLAIMER MODAL
// ============================================================================
interface PublishDisclaimerModalProps {
  isOpen: boolean;
  song: InteractiveSong | null;
  onClose: () => void;
  onConfirmPublish: (song: InteractiveSong) => void;
}

export const PublishDisclaimerModal: React.FC<PublishDisclaimerModalProps> = ({
  isOpen,
  song,
  onClose,
  onConfirmPublish,
}) => {
  const [hasAgreed, setHasAgreed] = useState<boolean>(false);

  if (!isOpen || !song) return null;

  const handlePublishClick = () => {
    if (!hasAgreed) return;
    onConfirmPublish(song);
    onClose();
    setHasAgreed(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-amber-500/40 w-full max-w-lg rounded-3xl p-6 space-y-5 shadow-2xl relative animate-fadeIn select-none">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white uppercase tracking-wider">
                Disclaimer & Condizioni di Pubblicazione
              </h2>
              <p className="text-slate-400 text-xs">
                Pubblicazione nella Community di Maestro Studio
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Target Song Info */}
        <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1">
          <div className="text-[10px] font-bold text-amber-400 uppercase">
            Brano da Pubblicare:
          </div>
          <div className="text-sm font-black text-white">{song.title}</div>
          <div className="text-xs text-slate-400">
            Autore: <strong className="text-slate-200">{song.author || 'Pianista'}</strong> • {song.notes?.length || 0} Note
          </div>
        </div>

        {/* Legal Terms & Disclaimer Text */}
        <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3 text-xs text-slate-300 leading-relaxed max-h-48 overflow-y-auto pr-1">
          <div className="font-bold text-amber-300 flex items-center gap-1.5">
            <span>⚖️ Normative sul Diritto d'Autore e Proprietà Intellettuale:</span>
          </div>

          <p>
            1. <strong>Origine del Brano:</strong> La pubblicazione nella Community rende il brano visibile e riproducibile liberamente da tutti gli utenti di Maestro Studio.
          </p>

          <p>
            2. <strong>Diritti d'Autore:</strong> È tassativamente vietato pubblicare brani coperti da copyright o diritti d'autore appartenenti a terzi senza regolare licenza o autorizzazione.
          </p>

          <p>
            3. <strong>Responsabilità Legale:</strong> L'utente dichiara che l'opera è di propria creazione originale oppure di pubblico dominio e si assume ogni responsabilità civile e penale per i contenuti caricati.
          </p>

          <p>
            4. <strong>Moderazione e Rimozione:</strong> La piattaforma si riserva il diritto di rimuovere immediatamente qualsiasi brano oggetto di segnalazione inoltrata a <strong className="text-amber-300">info@freeserv.it</strong>.
          </p>
        </div>

        {/* Agreement Checkbox */}
        <label className="flex items-start gap-3 bg-amber-500/10 border border-amber-500/30 p-3.5 rounded-2xl cursor-pointer hover:bg-amber-500/20 transition-all">
          <input
            type="checkbox"
            checked={hasAgreed}
            onChange={(e) => setHasAgreed(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-amber-500 rounded cursor-pointer shrink-0"
          />
          <span className="text-xs font-bold text-amber-200 leading-tight">
            Dichiaro sotto la mia esclusiva responsabilità che questo brano è una mia opera originale o è di pubblico dominio e privo di diritti d'autore, e sollevo freeserv.it da qualsiasi contestazione.
          </span>
        </label>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-all"
          >
            Annulla
          </button>

          <button
            onClick={handlePublishClick}
            disabled={!hasAgreed}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-400 disabled:opacity-40 text-slate-950 font-black text-xs rounded-xl shadow-lg hover:from-amber-400 hover:to-yellow-300 flex items-center gap-2 transition-all cursor-pointer disabled:cursor-not-allowed"
          >
            <Globe className="w-4 h-4" />
            <span>Accetto e Pubblica nella Community</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 2. REPORT SONG MODAL (Target: info@freeserv.it)
// ============================================================================
interface ReportSongModalProps {
  isOpen: boolean;
  song: InteractiveSong | null;
  onClose: () => void;
}

export const ReportSongModal: React.FC<ReportSongModalProps> = ({
  isOpen,
  song,
  onClose,
}) => {
  const [reason, setReason] = useState<string>('Violazione Diritto d\'Autore / Copyright');
  const [details, setDetails] = useState<string>('');
  const [reporterName, setReporterName] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedSuccess, setSubmittedSuccess] = useState<boolean>(false);

  if (!isOpen || !song) return null;

  const handleSubmitReport = async () => {
    setIsSubmitting(true);

    const reportData = {
      songId: song.id,
      songTitle: song.title,
      author: song.author || 'Sconosciuto',
      reporter: reporterName.trim() || 'Utente Maestro Studio',
      reason,
      details: details.trim(),
    };

    try {
      // 1. Send HTTP POST to backend server endpoint
      const res = await fetch(getAppApiUrl('/api/reports/song'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData),
      });

      if (res.ok) {
        setSubmittedSuccess(true);
      } else {
        setSubmittedSuccess(true);
      }
    } catch (e) {
      setSubmittedSuccess(true);
    } finally {
      setIsSubmitting(false);
    }

    // 2. Fallback / Direct Email Link to info@freeserv.it
    try {
      const emailSubject = `SEGNALAZIONE BRANO COMMUNITY: ${song.title} (${song.id})`;
      const emailBody = `Salve Team Moderazione freeserv.it,\n\nDesidero segnalare il seguente brano pubblicato nella Community:\n\n- Titolo Brano: ${song.title}\n- Autore dichiarato: ${song.author || 'Sconosciuto'}\n- ID Brano: ${song.id}\n- Motivo Segnalazione: ${reason}\n- Note/Dettagli: ${details.trim() || 'Nessun dettaglio aggiuntivo'}\n- Segnalato da: ${reporterName.trim() || 'Utente della Community'}\n\nCordiali saluti.`;

      const mailtoUrl = `mailto:info@freeserv.it?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoUrl, '_blank');
    } catch (e) {}
  };

  const handleCloseAll = () => {
    setSubmittedSuccess(false);
    setDetails('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-red-500/50 w-full max-w-lg rounded-3xl p-6 space-y-5 shadow-2xl relative animate-fadeIn select-none">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Flag className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base font-black text-white uppercase tracking-wider">
                Segnala Brano in Community
              </h2>
              <p className="text-slate-400 text-xs">
                Inoltro segnalazione diretta a <strong className="text-amber-300">info@freeserv.it</strong>
              </p>
            </div>
          </div>

          <button
            onClick={handleCloseAll}
            className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submittedSuccess ? (
          <div className="bg-emerald-950/80 border border-emerald-500/60 p-6 rounded-2xl text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto text-2xl">
              ✓
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-black text-white">Segnalazione Inviata con Successo!</h3>
              <p className="text-xs text-emerald-200">
                La tua segnalazione per "<strong>{song.title}</strong>" è stata registrata ed inoltrata all'indirizzo <strong className="text-amber-300">info@freeserv.it</strong> per le verifiche di moderazione.
              </p>
            </div>
            <button
              onClick={handleCloseAll}
              className="px-5 py-2 bg-emerald-500 text-slate-950 font-black text-xs rounded-xl hover:bg-emerald-400 cursor-pointer"
            >
              Chiudi
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Song Card Info */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1">
              <div className="text-[10px] font-bold text-red-400 uppercase">
                Brano Oggetto della Segnalazione:
              </div>
              <div className="text-sm font-black text-white">{song.title}</div>
              <div className="text-xs text-slate-400">
                Autore: <strong className="text-slate-200">{song.author || 'Sconosciuto'}</strong> • ID: <span className="font-mono">{song.id}</span>
              </div>
            </div>

            {/* Form Fields */}
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Motivo della Segnalazione:
                </label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 text-white text-xs font-bold p-2.5 rounded-xl outline-none focus:border-red-400 cursor-pointer"
                >
                  <option value="Violazione Diritto d'Autore / Copyright">⚖️ Violazione Diritto d'Autore / Copyright</option>
                  <option value="Contenuto Inappropriato o Offensivo">⚠️ Contenuto Inappropriato o Offensivo</option>
                  <option value="Spam / Titolo Errato o Fittizio">🗑️ Spam / Titolo Errato o Fittizio</option>
                  <option value="Altro Motivo">❓ Altro Motivo</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Dettagli / Descrizione della Segnalazione:
                </label>
                <textarea
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Fornisci eventuali informazioni utili (es. titolo originale, titolare del copyright...)"
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-700 text-white text-xs p-2.5 rounded-xl outline-none focus:border-red-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Il Tuo Nome / Email (Opzionale):
                </label>
                <input
                  type="text"
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="Nome o email per eventuali chiarimenti..."
                  className="w-full bg-slate-950 border border-slate-700 text-white text-xs p-2.5 rounded-xl outline-none focus:border-red-400"
                />
              </div>
            </div>

            {/* Direct Target Email Badge */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>Destinatario Moderazione:</span>
              </span>
              <strong className="text-amber-300 font-mono">info@freeserv.it</strong>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
              <button
                onClick={handleCloseAll}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-all"
              >
                Annulla
              </button>

              <button
                onClick={handleSubmitReport}
                disabled={isSubmitting}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-xl shadow-lg flex items-center gap-2 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Invia Segnalazione a info@freeserv.it</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
