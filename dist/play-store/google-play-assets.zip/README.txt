VIRTUKEYS - GOOGLE PLAY STORE ASSET PACKAGE
===================================================

This package contains all official graphics required by Google Play Console:

1. google-play-icon-512x512.png
   - Resolution: 512 x 512 px
   - Type: 32-bit PNG with alpha
   - Usage: App Icon in Google Play Store listing

2. google-play-feature-graphic-1024x500.png
   - Resolution: 1024 x 500 px
   - Type: 24-bit PNG
   - Usage: Feature Graphic banner at top of Google Play listing

3. SCREENSHOTS (1920 x 1080 Landscape, 16:9):
   - screenshot-1-piano-waterfall.png (88-Key Grand Piano & Falling Notes Cascade)
   - screenshot-2-sheet-composer.png (Dual-Staff Sheet Music Composer & Notation)
   - screenshot-3-jam-band.png (Live Multi-Track Jam Band & Acoustic Drums)
   - screenshot-4-scale-gym.png (Hanon Finger Drills & Scale Technique Gym)
   - screenshot-5-recordings-studio.png (Master Stereo Waveform & MIDI/WAV Export)
