import express from "express";
import { fileURLToPath } from "url";
import path from "path";
import fs from "fs";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "mock-key",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

async function startServer() {
  const app = express();
  app.use(express.json());

  // Serve self-contained update.sh script embedding server.js and dist as base64
  app.get("/update.sh", (req, res) => {
    try {
      const { execSync } = require("child_process");
      const distPath = path.join(process.cwd(), "dist");
      const serverJsPath = path.join(__dirname, "server.js");

      if (!fs.existsSync(distPath) || !fs.existsSync(serverJsPath)) {
        execSync("npm run build", { cwd: process.cwd() });
      }

      execSync("tar -czf dist.tar.gz dist", { cwd: process.cwd() });
      const tarPath = path.join(process.cwd(), "dist.tar.gz");

      const serverJsB64 = fs.readFileSync(serverJsPath).toString("base64");
      const distTarB64 = fs.readFileSync(tarPath).toString("base64");

      if (fs.existsSync(tarPath)) fs.unlinkSync(tarPath);

      const script = `#!/bin/bash
set -e

APP_DIR="/var/www/maestro-studio"
sudo mkdir -p "$APP_DIR"
sudo chown -R $USER:$USER "$APP_DIR"
cd "$APP_DIR"

echo "=== [1/5] Aggiornamento sistema e strumenti ==="
sudo apt update && sudo apt install -y curl git build-essential nginx

echo "=== [2/5] Installazione di Node.js 20 LTS ==="
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    echo "Node.js è già installato ($(node -v))"
fi

echo "=== [3/5] Estrazione file di produzione ==="
cat << 'B64_SERVER' > server.js.b64
${serverJsB64}
B64_SERVER
base64 -d server.js.b64 > server.js
rm -f server.js.b64

cat << 'B64_DIST' > dist.tar.gz.b64
${distTarB64}
B64_DIST
base64 -d dist.tar.gz.b64 > dist.tar.gz
tar -xzf dist.tar.gz
rm -f dist.tar.gz.b64 dist.tar.gz

echo "=== [4/5] Configurazione dipendenze di produzione ==="
cat << 'EOF' > package.json
{
  "name": "maestro-studio",
  "version": "1.0.0",
  "type": "module",
  "dependencies": {
    "@google/genai": "^2.4.0",
    "dotenv": "^17.2.3",
    "express": "^4.21.2"
  }
}
EOF
npm install --production

echo "=== [5/5] Configurazione sicura di Nginx (Preserva sottodomini) e PM2 ==="
NGINX_CONF="/etc/nginx/sites-available/freeserv"
if [ -f "$NGINX_CONF" ]; then
    sudo python3 -c '
conf_path = "/etc/nginx/sites-available/freeserv"
with open(conf_path, "r") as f:
    content = f.read()

song_block = """
    # App Song sulla porta 5000
    location /Song {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\$http_upgrade;
        proxy_set_header Connection '\''upgrade'\'';
        proxy_set_header Host \\$host;
        proxy_cache_bypass \\$http_upgrade;
    }
    location /song {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\$http_upgrade;
        proxy_set_header Connection '\''upgrade'\'';
        proxy_set_header Host \\$host;
        proxy_cache_bypass \\$http_upgrade;
    }
"""

if "location /Song" not in content and "server_name freeserv.it" in content:
    idx = content.find("server_name freeserv.it")
    brace_idx = content.find("}", idx)
    if brace_idx != -1:
        content = content[:brace_idx] + song_block + "\\n" + content[brace_idx:]
        with open(conf_path, "w") as f:
            f.write(content)
        print("Nginx config patched successfully preserving subdomains.")
'
fi

sudo ln -sf /etc/nginx/sites-available/freeserv /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx

if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
fi
pm2 kill || true
rm -f ~/.pm2/dump.pm2
PORT=5000 pm2 start server.js --name "maestro-studio" --cwd "$APP_DIR"
pm2 save

echo "===================================================================="
echo " AGGIORNAMENTO COMPLETATO CON SUCCESSO!"
echo " - Homepage principale: http://freeserv.it/"
echo " - App Song: http://freeserv.it/Song"
echo " - Sottodomini (chromapulse, orbitsnap) preservati!"
echo "===================================================================="
`;

      res.type("text/plain");
      res.send(script);
    } catch (e: any) {
      res.status(500).send("Error generating update script: " + e.message);
    }
  });

  // Serve compiled server.js for direct VPS updates
  app.get("/server.js", (req, res) => {
    try {
      const { execSync } = require("child_process");
      const jsPath = path.join(__dirname, "server.js");
      if (!fs.existsSync(jsPath)) {
        execSync("npm run build", { cwd: process.cwd() });
      }
      res.type("application/javascript");
      res.sendFile(jsPath);
    } catch (e: any) {
      res.status(500).send("Error serving server.js: " + e.message);
    }
  });

  // Serve dist.tar.gz archive for direct VPS updates
  app.get("/dist.tar.gz", (req, res) => {
    try {
      const { execSync } = require("child_process");
      const distPath = path.join(process.cwd(), "dist");
      if (!fs.existsSync(distPath)) {
        return res.status(404).send("dist/ not found. Run npm run build.");
      }
      const tarPath = path.join(process.cwd(), "dist.tar.gz");
      execSync("tar -czf dist.tar.gz dist", { cwd: process.cwd() });
      res.download(tarPath, "dist.tar.gz", (err) => {
        if (fs.existsSync(tarPath)) fs.unlinkSync(tarPath);
      });
    } catch (e: any) {
      res.status(500).send("Error creating dist archive: " + e.message);
    }
  });

  // Community Songs Storage Path
  const dataDir = path.join(process.cwd(), "data");
  const communitySongsFile = path.join(dataDir, "community_songs.json");

  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (!fs.existsSync(communitySongsFile)) {
    fs.writeFileSync(communitySongsFile, JSON.stringify([], null, 2));
  }

  app.get("/api/community-songs", (req, res) => {
    try {
      if (fs.existsSync(communitySongsFile)) {
        const raw = fs.readFileSync(communitySongsFile, "utf-8");
        const songs = JSON.parse(raw || "[]");
        return res.json(songs);
      }
      res.json([]);
    } catch (e: any) {
      console.error("Error reading community songs:", e);
      res.json([]);
    }
  });

  app.post("/api/community-songs", (req, res) => {
    try {
      const song = req.body;
      if (!song || !song.title || !song.notes) {
        return res.status(400).json({ error: "Titolo e note obbligatori" });
      }

      let songs = [];
      if (fs.existsSync(communitySongsFile)) {
        const raw = fs.readFileSync(communitySongsFile, "utf-8");
        songs = JSON.parse(raw || "[]");
      }

      const existingIdx = songs.findIndex((s: any) => s.id === song.id);
      const songToSave = {
        ...song,
        isPublished: true,
        createdAt: song.createdAt || new Date().toISOString()
      };

      if (existingIdx >= 0) {
        songs[existingIdx] = songToSave;
      } else {
        songs.unshift(songToSave);
      }

      fs.writeFileSync(communitySongsFile, JSON.stringify(songs, null, 2));
      res.json({ success: true, song: songToSave });
    } catch (e: any) {
      console.error("Error saving community song:", e);
      res.status(500).json({ error: e.message || "Failed to publish song" });
    }
  });

  // API endpoint for AI Music Composer & Arranger
  app.post("/api/gemini/compose", async (req, res) => {
    try {
      const { prompt, style, key } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: `You are an expert music composer and arranger. The user wants a song or progression with prompt: "${prompt}", style: "${style || "pop"}", musical key: "${key || "C major"}".Return a JSON object containing:1. title (string)2. description (string)3. key (string)4. bpm (number, between 60 and 160)5. chords (array of strings representing chords per measure, e.g. ["C", "Am", "F", "G"])6. melody (array of objects with { note: string (e.g. "C4"), duration: string ("4n" or "8n"), time: number (beat offset or step index 0-15) })7. bassline (array of objects with { note: string (e.g. "C2"), duration: string ("4n"), time: number })`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              key: { type: Type.STRING },
              bpm: { type: Type.NUMBER },
              chords: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              melody: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    note: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    time: { type: Type.NUMBER }
                  },
                  required: ["note", "duration", "time"]
                }
              },
              bassline: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    note: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    time: { type: Type.NUMBER }
                  },
                  required: ["note", "duration", "time"]
                }
              }
            },
            required: ["title", "description", "key", "bpm", "chords", "melody", "bassline"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      res.json(data);
    } catch (error: any) {
      console.error("Gemini compose error:", error);
      res.status(500).json({ error: error.message || "Failed to generate composition" });
    }
  });

  const distPath = path.resolve(process.cwd(), "dist");
  console.log(`[Server] Checking distPath: ${distPath}, exists: ${fs.existsSync(distPath)}`);

  if (fs.existsSync(distPath)) {
    // Serve static compiled assets directly
    app.use("/Song/assets", express.static(path.join(distPath, "assets")));
    app.use("/song/assets", express.static(path.join(distPath, "assets")));
    app.use("/assets", express.static(path.join(distPath, "assets")));
    app.use("/Song", express.static(distPath));
    app.use("/song", express.static(distPath));
    app.use(express.static(distPath));

    // SPA fallback: handle all paths so /, /Song, /Song/* etc. work everywhere
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    console.error("[CRITICAL] dist/ directory not found at:", distPath);
    app.get("*", (req, res) => {
      res.status(500).send("Server Error: Application not built. Please run 'npm run build' on the server.");
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
