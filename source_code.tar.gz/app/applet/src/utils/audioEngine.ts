import * as Tone from 'tone';
import { InstrumentType, JamStyle } from '../types';

class AudioEngine {
  private pianoSynth: Tone.PolySynth | null = null;
  private pianoFilter: Tone.Filter | null = null;
  private bassSynth: Tone.MonoSynth | null = null;
  private guitarSynth: Tone.PolySynth | null = null;
  private stringSynth: Tone.PolySynth | null = null;
  private drumSynth: Tone.MembraneSynth | null = null;
  private hihatSynth: Tone.MetalSynth | null = null;
  private snareSynth: Tone.NoiseSynth | null = null;

  private masterGain: Tone.Volume | null = null;

  private isInitialized = false;
  private isSustainOn = false;

  async init() {
    if (this.isInitialized) return;
    try {
      await Tone.start();
      // Master output: Direct clean gain with generous headroom (-16 dB) to prevent clipping & distortion
      this.masterGain = new Tone.Volume(-16).toDestination();

      // Piano Filter: Gentle lowpass filter at 2200 Hz that softens harsh digital edges into a warm, velvety acoustic tone
      this.pianoFilter = new Tone.Filter({
        frequency: 2200,
        type: 'lowpass',
        rolloff: -12,
        Q: 0.8,
      }).connect(this.masterGain);

      // Piano: Warm acoustic tone
      this.pianoSynth = new Tone.PolySynth(Tone.Synth).connect(this.pianoFilter);
      this.pianoSynth.volume.value = -12;

      // Bass Synth: Smooth, rounded bass
      this.bassSynth = new Tone.MonoSynth({
        volume: -8,
        oscillator: { type: 'sawtooth' },
        envelope: {
          attack: 0.05,
          decay: 0.3,
          sustain: 0.4,
          release: 0.4,
        },
        filterEnvelope: {
          attack: 0.01,
          decay: 0.3,
          sustain: 0.2,
          release: 0.4,
          baseFrequency: 100,
          octaves: 2.5,
        },
      }).connect(this.masterGain);

      // Guitar Synth
      this.guitarSynth = new Tone.PolySynth(Tone.Synth).connect(this.masterGain);
      this.guitarSynth.volume.value = -8;

      // Strings Synth
      this.stringSynth = new Tone.PolySynth(Tone.Synth).connect(this.masterGain);
      this.stringSynth.volume.value = -10;

      // Drum synths
      this.drumSynth = new Tone.MembraneSynth({
        volume: -6,
        pitchDecay: 0.05,
        octaves: 4,
        oscillator: { type: 'sine' },
        envelope: { attack: 0.001, decay: 0.3, sustain: 0.01, release: 0.3 },
      }).connect(this.masterGain);

      this.hihatSynth = new Tone.MetalSynth({
        volume: -18,
        frequency: 200,
        envelope: { attack: 0.001, decay: 0.05, release: 0.05 },
        harmonicity: 5.1,
        modulationIndex: 32,
        resonance: 4000,
        octaves: 1.5,
      }).connect(this.masterGain);

      this.snareSynth = new Tone.NoiseSynth({
        volume: -12,
        noise: { type: 'white' },
        envelope: { attack: 0.001, decay: 0.15, sustain: 0, release: 0.1 },
      }).connect(this.masterGain);

      this.isInitialized = true;
    } catch (e) {
      console.error('Failed to initialize audio engine', e);
    }
  }

  playNote(note: string, duration: string = '8n', instrument: InstrumentType = 'piano') {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now();
    try {
      if (instrument === 'piano' && this.pianoSynth) {
        this.pianoSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === 'guitar' && this.guitarSynth) {
        this.guitarSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === 'strings' && this.stringSynth) {
        this.stringSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === 'bass' && this.bassSynth) {
        this.bassSynth.triggerAttackRelease(note, duration, now);
      }
    } catch (e) {
      // Ignore audio scheduling overlaps
    }
  }

  setSustain(sustain: boolean) {
    this.isSustainOn = sustain;
  }

  playJamBeat(style: JamStyle, beatIndex: number) {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now();
    try {
      if (style === 'lofi') {
        if (beatIndex % 4 === 0) this.drumSynth?.triggerAttackRelease('C1', '8n', now);
        if (beatIndex % 4 === 2) this.snareSynth?.triggerAttackRelease('8n', now);
        if (beatIndex % 2 === 0) this.hihatSynth?.triggerAttackRelease('32n', now, 0.3);
      } else if (style === 'jazz') {
        if (beatIndex % 4 === 0 || beatIndex % 4 === 3) this.drumSynth?.triggerAttackRelease('C1', '8n', now);
        if (beatIndex % 4 === 2) this.snareSynth?.triggerAttackRelease('8n', now, 0.6);
        this.hihatSynth?.triggerAttackRelease('32n', now, 0.4);
      } else if (style === 'pop') {
        if (beatIndex % 4 === 0 || beatIndex % 4 === 2) this.drumSynth?.triggerAttackRelease('C1', '8n', now);
        if (beatIndex % 4 === 2) this.snareSynth?.triggerAttackRelease('8n', now);
        if (beatIndex % 2 === 0) this.hihatSynth?.triggerAttackRelease('32n', now, 0.5);
      } else if (style === 'classical') {
        if (beatIndex % 4 === 0) this.drumSynth?.triggerAttackRelease('G1', '2n', now, 0.4);
      }
    } catch (e) {
      // Ignore
    }
  }
}

export const audioEngine = new AudioEngine();
