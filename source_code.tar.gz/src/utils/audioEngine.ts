import * as Tone from "tone";
import { InstrumentType, JamStyle } from "../types";

class AudioEngine {
  private pianoSynth: Tone.PolySynth | null = null;
  private pianoFilter: Tone.Filter | null = null;
  private bassSynth: Tone.MonoSynth | null = null;
  private guitarSynth: Tone.PolySynth | null = null;
  private stringSynth: Tone.PolySynth | null = null;
  private drumSynth: Tone.MembraneSynth | null = null;
  private hihatSynth: Tone.MetalSynth | null = null;
  private snareSynth: Tone.NoiseSynth | null = null;

  private masterGain: Tone.Volume | null = null;

  private isInitialized = false;
  private isSustainOn = false;

  async init() {
    if (this.isInitialized) return;
    try {
      await Tone.start();
      this.masterGain = new Tone.Volume(-16).toDestination();

      this.pianoFilter = new Tone.Filter({
        frequency: 2200,
        type: "lowpass",
        rolloff: -12,
        Q: 0.8,
      }).connect(this.masterGain);

      this.pianoSynth = new Tone.PolySynth(Tone.Synth).connect(this.pianoFilter);
      this.pianoSynth.volume.value = -12;

      this.bassSynth = new Tone.MonoSynth({
        volume: -8,
        oscillator: { type: "sawtooth" },
        envelope: {
          attack: 0.05,
          decay: 0.3,
          sustain: 0.4,
          release: 0.4,
        },
        filterEnvelope: {
          attack: 0.01,
          decay: 0.3,
          sustain: 0.2,
          release: 0.4,
          baseFrequency: 100,
          octaves: 2.5,
        },
      }).connect(this.masterGain);

      this.guitarSynth = new Tone.PolySynth(Tone.Synth).connect(this.masterGain);
      this.guitarSynth.volume.value = -8;

      this.stringSynth = new Tone.PolySynth(Tone.Synth).connect(this.masterGain);
      this.stringSynth.volume.value = -10;

      this.drumSynth = new Tone.MembraneSynth({
        volume: -6,
        pitchDecay: 0.05,
        octaves: 4,
        oscillator: { type: "sine" },
        envelope: { attack: 0.001, decay: 0.3, sustain: 0.01, release: 0.3 },
      }).connect(this.masterGain);

      this.hihatSynth = new Tone.MetalSynth({ volume: -18 } as any).connect(this.masterGain);

      this.snareSynth = new Tone.NoiseSynth({
        volume: -12,
        noise: { type: "white" },
        envelope: { attack: 0.001, decay: 0.15, sustain: 0, release: 0.1 },
      }).connect(this.masterGain);

      this.isInitialized = true;
    } catch (e) {
      console.error("Failed to initialize audio engine", e);
    }
  }

  playNote(note: string, duration: string = "8n", instrument: InstrumentType = "piano") {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now();
    try {
      if (instrument === "piano" && this.pianoSynth) {
        this.pianoSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === "guitar" && this.guitarSynth) {
        this.guitarSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === "strings" && this.stringSynth) {
        this.stringSynth.triggerAttackRelease(note, duration, now);
      } else if (instrument === "bass" && this.bassSynth) {
        this.bassSynth.triggerAttackRelease(note, duration, now);
      }
    } catch (e) {}
  }

  playChord(notes: string[], duration: string = "2n", instrument: InstrumentType = "piano") {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now();
    try {
      if (instrument === "piano" && this.pianoSynth) {
        this.pianoSynth.triggerAttackRelease(notes, duration, now);
      } else if (instrument === "guitar" && this.guitarSynth) {
        this.guitarSynth.triggerAttackRelease(notes, duration, now);
      } else if (instrument === "strings" && this.stringSynth) {
        this.stringSynth.triggerAttackRelease(notes, duration, now);
      } else if (instrument === "bass" && this.bassSynth) {
        notes.forEach(n => this.bassSynth?.triggerAttackRelease(n, duration, now));
      }
    } catch (e) {}
  }

  playDrum(type: string, time: number = 0) {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now() + time;
    try {
      if (type === "kick") {
        this.drumSynth?.triggerAttackRelease("C1", "8n", now);
      } else if (type === "snare") {
        this.snareSynth?.triggerAttackRelease("8n", now);
      } else if (type === "hihat") {
        this.hihatSynth?.triggerAttackRelease("32n", now, 0.4);
      }
    } catch (e) {}
  }

  setSustain(sustain: boolean) {
    this.isSustainOn = sustain;
  }

  setVolume(vol: number) {
    if (this.masterGain) {
      this.masterGain.volume.value = vol;
    }
  }

  playJamBeat(style: string, beatIndex: number) {
    if (!this.isInitialized) {
      this.init();
    }
    const now = Tone.now();
    try {
      if (style === "lofi" || style === "blues") {
        if (beatIndex % 4 === 0) this.playDrum("kick", 0);
        if (beatIndex % 4 === 2) this.playDrum("snare", 0);
        if (beatIndex % 2 === 0) this.playDrum("hihat", 0);
      } else if (style === "jazz" || style === "bossa") {
        if (beatIndex % 4 === 0 || beatIndex % 4 === 3) this.playDrum("kick", 0);
        if (beatIndex % 4 === 2) this.playDrum("snare", 0);
        this.playDrum("hihat", 0);
      } else if (style === "pop" || style === "rock") {
        if (beatIndex % 4 === 0 || beatIndex % 4 === 2) this.playDrum("kick", 0);
        if (beatIndex % 4 === 2) this.playDrum("snare", 0);
        if (beatIndex % 2 === 0) this.playDrum("hihat", 0);
      } else {
        if (beatIndex % 4 === 0) this.playDrum("kick", 0);
      }
    } catch (e) {}
  }
}

export const audioEngine = new AudioEngine();
