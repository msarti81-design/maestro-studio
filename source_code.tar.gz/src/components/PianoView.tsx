import React, { useState, useEffect, useCallback, useRef } from 'react';
import { audioEngine } from '../utils/audioEngine';
import { InstrumentType, RecordedNote, InteractiveSong } from '../types';
import {
  Play,
  RotateCcw,
  Volume2,
  Plus,
  Minus,
  Home,
  Music,
  Maximize,
  Minimize,
  Smartphone,
  BookOpen,
  User,
  Sparkles,
  Share2,
  HardDrive,
  Save,
  Check,
  MoreHorizontal,
  Settings,
  X,
  Sliders,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { FallingNotesWaterfall } from './FallingNotesWaterfall';
import { SongLibraryModal } from './SongLibraryModal';
import { getUsername, getPublishedSongs } from '../utils/songStorage';

export interface KeyConfig {
  note: string;
  type: 'white' | 'black';
  computerKey?: string;
  octave: number;
}

// Comfortable wide keys for gameplay view (C3 to G5 - exactly fits horizontal screen)
export type KeyboardLayoutType = 'compact' | 'balanced' | 'extended';

export const COMPACT_KEYS: KeyConfig[] = [
  { note: 'C4', type: 'white', octave: 4, computerKey: 'a' },
  { note: 'C#4', type: 'black', octave: 4, computerKey: 'w' },
  { note: 'D4', type: 'white', octave: 4, computerKey: 's' },
  { note: 'D#4', type: 'black', octave: 4, computerKey: 'e' },
  { note: 'E4', type: 'white', octave: 4, computerKey: 'd' },
  { note: 'F4', type: 'white', octave: 4, computerKey: 'f' },
  { note: 'F#4', type: 'black', octave: 4, computerKey: 't' },
  { note: 'G4', type: 'white', octave: 4, computerKey: 'g' },
  { note: 'G#4', type: 'black', octave: 4, computerKey: 'y' },
  { note: 'A4', type: 'white', octave: 4, computerKey: 'h' },
  { note: 'A#4', type: 'black', octave: 4, computerKey: 'u' },
  { note: 'B4', type: 'white', octave: 4, computerKey: 'j' },

  { note: 'C5', type: 'white', octave: 5, computerKey: 'k' },
  { note: 'C#5', type: 'black', octave: 5, computerKey: 'o' },
  { note: 'D5', type: 'white', octave: 5, computerKey: 'l' },
  { note: 'D#5', type: 'black', octave: 5, computerKey: 'p' },
  { note: 'E5', type: 'white', octave: 5, computerKey: ';' },
  { note: 'F5', type: 'white', octave: 5, computerKey: '\'' },
  { note: 'F#5', type: 'black', octave: 5, computerKey: ']' },
  { note: 'G5', type: 'white', octave: 5, computerKey: 'z' },
  { note: 'G#5', type: 'black', octave: 5, computerKey: 'x' },
  { note: 'A5', type: 'white', octave: 5, computerKey: 'c' },
  { note: 'A#5', type: 'black', octave: 5, computerKey: 'v' },
  { note: 'B5', type: 'white', octave: 5, computerKey: 'b' },
  { note: 'C6', type: 'white', octave: 6, computerKey: 'n' },
];

export const BALANCED_KEYS: KeyConfig[] = [
  { note: 'C3', type: 'white', octave: 3, computerKey: 'a' },
  { note: 'C#3', type: 'black', octave: 3, computerKey: 'w' },
  { note: 'D3', type: 'white', octave: 3, computerKey: 's' },
  { note: 'D#3', type: 'black', octave: 3, computerKey: 'e' },
  { note: 'E3', type: 'white', octave: 3, computerKey: 'd' },
  { note: 'F3', type: 'white', octave: 3, computerKey: 'f' },
  { note: 'F#3', type: 'black', octave: 3, computerKey: 't' },
  { note: 'G3', type: 'white', octave: 3, computerKey: 'g' },
  { note: 'G#3', type: 'black', octave: 3, computerKey: 'y' },
  { note: 'A3', type: 'white', octave: 3, computerKey: 'h' },
  { note: 'A#3', type: 'black', octave: 3, computerKey: 'u' },
  { note: 'B3', type: 'white', octave: 3, computerKey: 'j' },

  { note: 'C4', type: 'white', octave: 4, computerKey: 'k' },
  { note: 'C#4', type: 'black', octave: 4, computerKey: 'o' },
  { note: 'D4', type: 'white', octave: 4, computerKey: 'l' },
  { note: 'D#4', type: 'black', octave: 4, computerKey: 'p' },
  { note: 'E4', type: 'white', octave: 4, computerKey: ';' },
  { note: 'F4', type: 'white', octave: 4, computerKey: '\'' },
  { note: 'F#4', type: 'black', octave: 4, computerKey: ']' },
  { note: 'G4', type: 'white', octave: 4, computerKey: 'z' },
  { note: 'G#4', type: 'black', octave: 4, computerKey: 'x' },
  { note: 'A4', type: 'white', octave: 4, computerKey: 'c' },
  { note: 'A#4', type: 'black', octave: 4, computerKey: 'v' },
  { note: 'B4', type: 'white', octave: 4, computerKey: 'b' },

  { note: 'C5', type: 'white', octave: 5, computerKey: 'n' },
  { note: 'C#5', type: 'black', octave: 5, computerKey: 'm' },
  { note: 'D5', type: 'white', octave: 5, computerKey: ',' },
  { note: 'D#5', type: 'black', octave: 5, computerKey: '.' },
  { note: 'E5', type: 'white', octave: 5, computerKey: '/' },
  { note: 'F5', type: 'white', octave: 5 },
  { note: 'F#5', type: 'black', octave: 5 },
  { note: 'G5', type: 'white', octave: 5 },
];

export const EXTENDED_KEYS: KeyConfig[] = [
  { note: 'C3', type: 'white', octave: 3, computerKey: 'a' },
  { note: 'C#3', type: 'black', octave: 3, computerKey: 'w' },
  { note: 'D3', type: 'white', octave: 3, computerKey: 's' },
  { note: 'D#3', type: 'black', octave: 3, computerKey: 'e' },
  { note: 'E3', type: 'white', octave: 3, computerKey: 'd' },
  { note: 'F3', type: 'white', octave: 3, computerKey: 'f' },
  { note: 'F#3', type: 'black', octave: 3, computerKey: 't' },
  { note: 'G3', type: 'white', octave: 3, computerKey: 'g' },
  { note: 'G#3', type: 'black', octave: 3, computerKey: 'y' },
  { note: 'A3', type: 'white', octave: 3, computerKey: 'h' },
  { note: 'A#3', type: 'black', octave: 3, computerKey: 'u' },
  { note: 'B3', type: 'white', octave: 3, computerKey: 'j' },

  { note: 'C4', type: 'white', octave: 4, computerKey: 'k' },
  { note: 'C#4', type: 'black', octave: 4, computerKey: 'o' },
  { note: 'D4', type: 'white', octave: 4, computerKey: 'l' },
  { note: 'D#4', type: 'black', octave: 4, computerKey: 'p' },
  { note: 'E4', type: 'white', octave: 4, computerKey: ';' },
  { note: 'F4', type: 'white', octave: 4, computerKey: '\'' },
  { note: 'F#4', type: 'black', octave: 4, computerKey: ']' },
  { note: 'G4', type: 'white', octave: 4, computerKey: 'z' },
  { note: 'G#4', type: 'black', octave: 4, computerKey: 'x' },
  { note: 'A4', type: 'white', octave: 4, computerKey: 'c' },
  { note: 'A#4', type: 'black', octave: 4, computerKey: 'v' },
  { note: 'B4', type: 'white', octave: 4, computerKey: 'b' },

  { note: 'C5', type: 'white', octave: 5, computerKey: 'n' },
  { note: 'C#5', type: 'black', octave: 5, computerKey: 'm' },
  { note: 'D5', type: 'white', octave: 5, computerKey: ',' },
  { note: 'D#5', type: 'black', octave: 5, computerKey: '.' },
  { note: 'E5', type: 'white', octave: 5, computerKey: '/' },
  { note: 'F5', type: 'white', octave: 5 },
  { note: 'F#5', type: 'black', octave: 5 },
  { note: 'G5', type: 'white', octave: 5 },
  { note: 'G#5', type: 'black', octave: 5 },
  { note: 'A5', type: 'white', octave: 5 },
  { note: 'A#5', type: 'black', octave: 5 },
  { note: 'B5', type: 'white', octave: 5 },
  { note: 'C6', type: 'white', octave: 6 },
];

const CHORD_PRESETS = [
  { name: 'C Major', notes: ['C4', 'E4', 'G4'] },
  { name: 'A Minor', notes: ['A3', 'C4', 'E4'] },
  { name: 'F Major', notes: ['F3', 'A3', 'C4'] },
  { name: 'G Major', notes: ['G3', 'B3', 'D4'] },
  { name: 'D Minor', notes: ['D4', 'F4', 'A4'] },
  { name: 'E7', notes: ['E3', 'G#3', 'B3', 'D4'] },
];

interface PianoViewProps {
  onBackToHome: () => void;
}

export const PianoView: React.FC<PianoViewProps> = ({ onBackToHome }) => {
  const [instrument, setInstrument] = useState<InstrumentType>('piano');
  const [sustain, setSustain] = useState<boolean>(false);
  const [keyboardLayout, setKeyboardLayout] = useState<KeyboardLayoutType>('balanced');
  const GAMEPLAY_KEYS = keyboardLayout === 'compact' ? COMPACT_KEYS : keyboardLayout === 'extended' ? EXTENDED_KEYS : BALANCED_KEYS;
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  const [octaveShift, setOctaveShift] = useState<number>(0); // -1, 0, +1

  // Username
  const [username, setUsernameState] = useState<string>(() => getUsername());

  // Interactive Falling Notes (Waterfall) Song State
  const [activeSong, setActiveSong] = useState<InteractiveSong | null>(() => {
    const list = getPublishedSongs();
    return list.length > 0 ? list[0] : null; // Pre-load Ode to Joy
  });
  const [showWaterfall, setShowWaterfall] = useState<boolean>(true);
  const [lastPlayedNote, setLastPlayedNote] = useState<{ note: string; timestamp: number } | null>(null);

  // Library & Song Creator Modal
  const [isLibraryOpen, setIsLibraryOpen] = useState<boolean>(false);
  const [newRecordedSongData, setNewRecordedSongData] = useState<{
    notes: { note: string; time: number; duration: number }[];
  } | null>(null);

  // Recording state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordStartTime, setRecordStartTime] = useState<number>(0);
  const [recordedNotes, setRecordedNotes] = useState<RecordedNote[]>([]);
  const [isPlayingRecording, setIsPlayingRecording] = useState<boolean>(false);
  // Options / Settings Modal (3 puntini ...)
  const [isOptionsModalOpen, setIsOptionsModalOpen] = useState<boolean>(false);

  // Forced Landscape and Orientation State
  const [isPortrait, setIsPortrait] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerHeight > window.innerWidth;
    }
    return false;
  });
  const [forceLandscape, setForceLandscape] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Glissando / Swipe References
  const isMouseDownRef = useRef<boolean>(false);
  const currentMouseNoteRef = useRef<string | null>(null);
  const activeTouchesRef = useRef<Map<number, string>>(new Map());
  const activeKeysRafRef = useRef<number | null>(null);
  const keyboardScrollRef = useRef<HTMLDivElement>(null);

  const scrollKeyboard = (direction: 'left' | 'right') => {
    if (keyboardScrollRef.current) {
      const amount = direction === 'left' ? -250 : 250;
      keyboardScrollRef.current.scrollBy({ left: amount, behavior: 'smooth' });
    }
  };

  // Handle Orientation and Fullscreen
  useEffect(() => {
    document.body.style.overflow = 'hidden';

    const checkOrientation = () => {
      setIsPortrait(window.innerHeight > window.innerWidth);
      const doc = document as any;
      setIsFullscreen(Boolean(document.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement));
    };

    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    document.addEventListener('fullscreenchange', checkOrientation);
    document.addEventListener('webkitfullscreenchange', checkOrientation);

    // Mouse up listener for desktop glissando
    const handleGlobalMouseUp = () => {
      isMouseDownRef.current = false;
      if (currentMouseNoteRef.current) {
        handleNoteUp(currentMouseNoteRef.current);
        currentMouseNoteRef.current = null;
      }
    };
    window.addEventListener('mouseup', handleGlobalMouseUp);

    try {
      if (screen.orientation && (screen.orientation as any).lock) {
        (screen.orientation as any).lock('landscape').catch(() => {});
      }
    } catch (e) {
      // Ignore if not permitted without user gesture
    }

    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
      document.removeEventListener('fullscreenchange', checkOrientation);
      document.removeEventListener('webkitfullscreenchange', checkOrientation);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
      if (activeKeysRafRef.current) {
        cancelAnimationFrame(activeKeysRafRef.current);
      }
    };
  }, []);

  const toggleFullscreen = async () => {
    try {
      const doc = document as any;
      const docEl = document.documentElement as any;
      const isFs = Boolean(document.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement);
      if (!isFs) {
        if (docEl.requestFullscreen) {
          await docEl.requestFullscreen();
        } else if (docEl.webkitRequestFullscreen) {
          await docEl.webkitRequestFullscreen();
        }
        if (screen.orientation && (screen.orientation as any).lock) {
          (screen.orientation as any).lock('landscape').catch(() => {});
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if (doc.webkitExitFullscreen) {
          await doc.webkitExitFullscreen();
        }
      }
    } catch (e) {
      console.warn('Fullscreen toggle:', e);
    }
  };

  const getTransposedNote = useCallback((baseNote: string): string => {
    const noteName = baseNote.slice(0, -1);
    const baseOctave = parseInt(baseNote.slice(-1));
    const newOctave = baseOctave + octaveShift;
    return `${noteName}${newOctave}`;
  }, [octaveShift]);

  // Helper to directly toggle DOM visual state with 0ms delay during fast finger sliding
  const applyDomKeyVisual = (note: string, active: boolean) => {
    const els = document.querySelectorAll(`[data-note="${note}"]`);
    els.forEach((el) => {
      if (active) {
        el.classList.add('key-pressed-active');
      } else {
        el.classList.remove('key-pressed-active');
      }
    });
  };

  const handleNoteDown = useCallback((baseNote: string) => {
    applyDomKeyVisual(baseNote, true);
    const note = getTransposedNote(baseNote);
    audioEngine.playNote(note, '8n', instrument);
    window.dispatchEvent(new CustomEvent('piano:noteplayed', { detail: { note } }));
    setActiveKeys((prev) => new Set(prev).add(baseNote));

    if (isRecording) {
      const now = (Date.now() - recordStartTime) / 1000;
      setRecordedNotes((prev) => [...prev, { note, time: now, duration: 0.5 }]);
    }
  }, [instrument, isRecording, recordStartTime, getTransposedNote]);

  const handleNoteUp = useCallback((baseNote: string) => {
    applyDomKeyVisual(baseNote, false);
    if (!sustain) {
      setActiveKeys((prev) => {
        const next = new Set(prev);
        next.delete(baseNote);
        return next;
      });
    }
  }, [sustain]);

  // GLISSANDO / SCALE TOUCH SWIPE HANDLERS (Ultra-fast 0ms latency)
  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      const el = document.elementFromPoint(touch.clientX, touch.clientY);
      const keyEl = el?.closest('[data-note]') as HTMLElement;
      if (keyEl && keyEl.dataset.note) {
        const note = keyEl.dataset.note;
        activeTouchesRef.current.set(touch.identifier, note);
        applyDomKeyVisual(note, true);
        handleNoteDown(note);
      }
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    let hasChanged = false;
    const toRemove: string[] = [];
    const toAdd: string[] = [];

    for (let i = 0; i < e.touches.length; i++) {
      const touch = e.touches[i];
      const el = document.elementFromPoint(touch.clientX, touch.clientY);
      const keyEl = el?.closest('[data-note]') as HTMLElement;
      const newNote = keyEl?.dataset.note || null;
      const prevNote = activeTouchesRef.current.get(touch.identifier);

      if (newNote !== prevNote) {
        hasChanged = true;
        if (prevNote) {
          applyDomKeyVisual(prevNote, false);
          toRemove.push(prevNote);
        }
        if (newNote) {
          activeTouchesRef.current.set(touch.identifier, newNote);
          applyDomKeyVisual(newNote, true);
          toAdd.push(newNote);
          // Play sound immediately without awaiting
          const actualNote = getTransposedNote(newNote);
          audioEngine.playNote(actualNote, '8n', instrument);
          window.dispatchEvent(new CustomEvent('piano:noteplayed', { detail: { note: actualNote } }));

          if (isRecording) {
            const now = (Date.now() - recordStartTime) / 1000;
            setRecordedNotes((prev) => [...prev, { note: actualNote, time: now, duration: 0.5 }]);
          }
        } else {
          activeTouchesRef.current.delete(touch.identifier);
        }
      }
    }

    if (hasChanged) {
      if (activeKeysRafRef.current) cancelAnimationFrame(activeKeysRafRef.current);
      activeKeysRafRef.current = requestAnimationFrame(() => {
        setActiveKeys((prev) => {
          const next = new Set(prev);
          if (!sustain) {
            toRemove.forEach((n) => next.delete(n));
          }
          toAdd.forEach((n) => next.add(n));
          return next;
        });
      });
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    if (activeKeysRafRef.current) cancelAnimationFrame(activeKeysRafRef.current);
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      const prevNote = activeTouchesRef.current.get(touch.identifier);
      if (prevNote) {
        applyDomKeyVisual(prevNote, false);
        handleNoteUp(prevNote);
        activeTouchesRef.current.delete(touch.identifier);
      }
    }
    if (activeTouchesRef.current.size === 0) {
      document.querySelectorAll('.key-pressed-active').forEach((el) => el.classList.remove('key-pressed-active'));
    }
  };

  // MOUSE DRAG / GLISSANDO HANDLERS
  const handleMouseDownKey = (baseNote: string) => {
    isMouseDownRef.current = true;
    currentMouseNoteRef.current = baseNote;
    applyDomKeyVisual(baseNote, true);
    handleNoteDown(baseNote);
  };

  const handleMouseEnterKey = (baseNote: string) => {
    if (isMouseDownRef.current && currentMouseNoteRef.current !== baseNote) {
      const oldNote = currentMouseNoteRef.current;
      currentMouseNoteRef.current = baseNote;
      if (oldNote) {
        applyDomKeyVisual(oldNote, false);
      }
      applyDomKeyVisual(baseNote, true);

      const actualNote = getTransposedNote(baseNote);
      audioEngine.playNote(actualNote, '8n', instrument);
      window.dispatchEvent(new CustomEvent('piano:noteplayed', { detail: { note: actualNote } }));

      setActiveKeys((prev) => {
        const next = new Set(prev);
        if (oldNote && !sustain) next.delete(oldNote);
        next.add(baseNote);
        return next;
      });
    }
  };

  const handleMouseLeaveKey = (baseNote: string) => {
    if (isMouseDownRef.current && currentMouseNoteRef.current === baseNote) {
      applyDomKeyVisual(baseNote, false);
      handleNoteUp(baseNote);
      currentMouseNoteRef.current = null;
    }
  };

  // Computer keyboard bindings
  useEffect(() => {
    const keyMap: Record<string, string> = {};
    GAMEPLAY_KEYS.forEach((k) => {
      if (k.computerKey) keyMap[k.computerKey] = k.note;
    });

    const pressedKeys = new Set<string>();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const baseNote = keyMap[e.key.toLowerCase()];
      if (baseNote && !pressedKeys.has(e.key)) {
        pressedKeys.add(e.key);
        handleNoteDown(baseNote);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const baseNote = keyMap[e.key.toLowerCase()];
      if (baseNote) {
        pressedKeys.delete(e.key);
        handleNoteUp(baseNote);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleNoteDown, handleNoteUp]);

  const toggleRecording = () => {
    if (!isRecording) {
      setRecordedNotes([]);
      setRecordStartTime(Date.now());
      setIsRecording(true);
    } else {
      setIsRecording(false);
      // If notes were recorded, offer to save/publish!
      if (recordedNotes.length > 0) {
        setNewRecordedSongData({
          notes: recordedNotes.map((r) => ({
            note: r.note,
            time: r.time,
            duration: r.duration || 0.5,
          })),
        });
        setIsLibraryOpen(true);
      }
    }
  };

  const playRecording = async () => {
    if (recordedNotes.length === 0 || isPlayingRecording) return;
    setIsPlayingRecording(true);
    const start = Date.now();

    for (const rn of recordedNotes) {
      const targetTime = rn.time * 1000;
      const elapsed = Date.now() - start;
      const delay = targetTime - elapsed;
      if (delay > 0) {
        await new Promise((r) => setTimeout(r, delay));
      }
      audioEngine.playNote(rn.note, '4n', instrument);
      setActiveKeys(new Set([rn.note.slice(0, -1) + '3']));
      setTimeout(() => setActiveKeys(new Set()), 300);
    }
    setIsPlayingRecording(false);
  };

  const isRotated = isPortrait && forceLandscape;
  const containerStyle: React.CSSProperties = isRotated
    ? {
        position: 'fixed',
        top: '50%',
        left: '50%',
        width: '100dvh',
        height: '100dvw',
        transform: 'translate(-50%, -50%) rotate(90deg)',
        transformOrigin: 'center center',
        zIndex: 50,
        boxSizing: 'border-box',
        overflow: 'hidden',
      }
    : {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100%',
        height: '100dvh',
        zIndex: 50,
        boxSizing: 'border-box',
        overflow: 'hidden',
      };

  return (
    <div
      style={containerStyle}
      className="bg-slate-950 flex flex-col h-full w-full overflow-hidden select-none touch-none p-0 m-0"
    >
      {/* ULTRA-COMPACT SINGLE LINE TOP BAR (Max 38px, immune to browser header overlap) */}
      <div
        style={{
          paddingTop: 'max(env(safe-area-inset-top, 0px), 2px)',
          paddingLeft: 'max(env(safe-area-inset-left, 0px), 8px)',
          paddingRight: 'max(env(safe-area-inset-right, 0px), 8px)',
        }}
        className="min-h-[38px] bg-slate-900/95 border-b border-slate-800/80 px-2 flex items-center justify-between shrink-0 z-20 text-xs"
      >
        {/* Left: Home & User & Library */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={onBackToHome}
            className="p-1 sm:px-2 sm:py-1 text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-750 rounded-lg flex items-center gap-1 transition-colors"
            title="Torna al Menu"
          >
            <Home className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline text-[11px] font-bold">Menu</span>
          </button>

          {/* User badge */}
          <button
            onClick={() => setIsLibraryOpen(true)}
            className="flex items-center gap-1 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 px-2 py-0.5 rounded-lg text-[11px] text-slate-200 transition-colors"
            title="Profilo & Nome Utente"
          >
            <User className="w-3 h-3 text-amber-400" />
            <span className="font-semibold text-white max-w-[80px] sm:max-w-[110px] truncate">{username}</span>
          </button>

          {/* Library Button */}
          <button
            onClick={() => setIsLibraryOpen(true)}
            className="px-2 py-0.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] rounded-lg flex items-center gap-1 shadow-sm transition-all active:scale-95"
            title="Apri libreria spartiti"
          >
            <BookOpen className="w-3 h-3" />
            <span>Spartiti</span>
          </button>

          {/* Toggle Falling Notes if song active */}
          {activeSong && (
            <button
              onClick={() => setShowWaterfall(!showWaterfall)}
              className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg flex items-center gap-1 transition-colors ${
                showWaterfall
                  ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
              title="Mostra / Nascondi note a cascata"
            >
              <Sparkles className="w-3 h-3" />
              <span className="hidden sm:inline">{showWaterfall ? 'Note ON' : 'Note OFF'}</span>
            </button>
          )}
        </div>

        {/* Center: Active Song Title or Quick Octave */}
        <div className="flex items-center gap-1 text-[11px]">
          <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider hidden sm:inline">Ottava:</span>
          <button
            onClick={() => setOctaveShift((prev) => Math.max(-1, prev - 1))}
            disabled={octaveShift <= -1}
            className="w-5 h-5 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-30 text-xs font-bold"
            title="Ottava più bassa"
          >
            -
          </button>
          <span className="px-1 text-[11px] font-black text-amber-400 min-w-[20px] text-center">
            {octaveShift >= 0 ? `+${octaveShift}` : octaveShift}
          </span>
          <button
            onClick={() => setOctaveShift((prev) => Math.min(1, prev + 1))}
            disabled={octaveShift >= 1}
            className="w-5 h-5 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-30 text-xs font-bold"
            title="Ottava più alta"
          >
            +
          </button>

          {/* Keyboard Layout Selector Pills */}
          <div className="flex items-center gap-0.5 bg-slate-800/80 rounded px-1 py-0.5 border border-slate-700 ml-1">
            {(["compact", "balanced", "extended"] as KeyboardLayoutType[]).map((layout) => (
              <button
                key={layout}
                onClick={() => setKeyboardLayout(layout)}
                className={`px-1.5 py-0.5 text-[10px] font-bold rounded capitalize transition-all ${
                  keyboardLayout === layout
                    ? "bg-amber-500 text-slate-950 shadow"
                    : "text-slate-300 hover:text-white bg-slate-800"
                }`}
                title={`Seleziona tastiera ${layout}`}
              >
                {layout === "compact" ? "Comp" : layout === "balanced" ? "Bal" : "Ext"}
              </button>
            ))}
          </div>

          {/* Keyboard Scroll Buttons */}
          <div className="flex items-center gap-0.5 bg-slate-800/80 rounded px-1 border border-slate-700 ml-1">
            <button
              onClick={() => scrollKeyboard('left')}
              className="w-5 h-5 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs"
              title="Scorri tastiera a sinistra"
            >
              <ChevronLeft className="w-3.5 h-3.5 text-amber-400" />
            </button>
            <button
              onClick={() => scrollKeyboard('right')}
              className="w-5 h-5 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs"
              title="Scorri tastiera a destra"
            >
              <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>

        {/* Right: Record, Sustain, Fullscreen & 3 DOTS MODAL BUTTON */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {/* Quick Record */}
          <button
            onClick={toggleRecording}
            className={`px-2 py-0.5 text-[11px] font-bold rounded-lg flex items-center gap-1 transition-colors ${
              isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
            title={isRecording ? 'Termina registrazione e salva spartito' : 'Registra'}
          >
            <div className={`w-2 h-2 rounded-full ${isRecording ? 'bg-white' : 'bg-red-500'}`} />
            <span className="hidden sm:inline">{isRecording ? 'Stop' : 'Rec'}</span>
          </button>

          {/* Quick Sustain toggle */}
          <button
            onClick={() => {
              const next = !sustain;
              setSustain(next);
              audioEngine.setSustain(next);
            }}
            className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg border transition-colors ${
              sustain
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
            }`}
            title="Sustain (tieni premuto il suono)"
          >
            Pedale
          </button>

          {/* Fullscreen toggle */}
          <button
            onClick={toggleFullscreen}
            className="p-1 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            title="Schermo Intero"
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
          </button>

          {/* 3 PUNTINI (...) MENU BUTTON */}
          <button
            onClick={() => setIsOptionsModalOpen(true)}
            className="p-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 hover:text-amber-300 border border-amber-500/30 rounded-lg transition-all"
            title="Tutte le impostazioni e scelte (...)"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* SYNTHESIA FALLING NOTES WATERFALL: Fills all remaining upper vertical space */}
      {showWaterfall && activeSong ? (
        <div className="flex-1 w-full flex flex-col min-h-0 bg-slate-950 overflow-hidden">
          <FallingNotesWaterfall
            song={activeSong}
            keys={GAMEPLAY_KEYS}
            getTransposedNote={getTransposedNote}
            onClose={() => setShowWaterfall(false)}
            lastPlayedNote={lastPlayedNote}
          />
        </div>
      ) : (
        /* When waterfall is hidden, compact chords strip */
        <div className="flex items-center justify-center gap-1.5 py-1 px-2 bg-slate-950 border-b border-slate-900 shrink-0">
          <span className="text-[10px] text-slate-500 uppercase font-bold">Accordi Rapidi:</span>
          {CHORD_PRESETS.map((chord) => (
            <button
              key={chord.name}
              onClick={() => audioEngine.playChord(chord.notes.map((n) => getTransposedNote(n)), '2n', instrument)}
              className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 hover:text-amber-400 text-[11px] font-semibold"
            >
              {chord.name}
            </button>
          ))}
        </div>
      )}

      {/* GLOWING DIVIDING HORIZONTAL LINE (Riga orizzontale che divide i tasti dalle note) */}
      <div className="w-full h-1 bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.95)] z-10 shrink-0" />

      {/* PIANO KEYBOARD CONTAINER: Sits right on the bottom, fills comfortable height */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        style={{
          paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 4px)',
        }}
        className="w-full bg-slate-950 p-1 sm:p-1.5 shrink-0 select-none touch-none"
      >
        <div className="relative flex justify-start sm:justify-center w-full overflow-x-auto scrollbar-none" ref={keyboardScrollRef}>
          <div className="relative flex w-full min-w-[780px] sm:min-w-[920px] justify-center h-[36dvh] max-h-[195px] min-h-[110px]">
            {/* White Keys */}
            <div className="flex w-full h-full justify-between gap-0.5 sm:gap-1">
              {GAMEPLAY_KEYS.filter((k) => k.type === 'white').map((k) => {
                const isActive = activeKeys.has(k.note);
                const actualNote = getTransposedNote(k.note);
                return (
                  <button
                    key={k.note}
                    data-note={k.note}
                    onMouseDown={() => handleMouseDownKey(k.note)}
                    onMouseEnter={() => handleMouseEnterKey(k.note)}
                    onMouseLeave={() => handleMouseLeaveKey(k.note)}
                    className={`key-white relative flex-1 h-full rounded-b-lg border border-slate-300 transition-none flex flex-col justify-end pb-2 sm:pb-2.5 items-center text-xs font-bold shadow-md select-none touch-none ${
                      isActive
                        ? 'key-pressed-active bg-amber-400 text-slate-950 border-amber-500 shadow-[0_0_15px_rgba(251,191,36,0.8)]'
                        : 'bg-white text-slate-800'
                    }`}
                  >
                    <span className="opacity-90 text-[11px] sm:text-xs font-extrabold">{actualNote}</span>
                    {k.computerKey && (
                      <span className="text-[8px] opacity-40 uppercase bg-slate-200 px-0.5 py-0.5 rounded mt-0.5 hidden sm:inline">
                        {k.computerKey}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Black Keys Overlay */}
            <div className="absolute top-0 left-0 right-0 h-full flex justify-center pointer-events-none px-1">
              <div className="relative w-full h-full px-1">
                {GAMEPLAY_KEYS.map((k, idx) => {
                  if (k.type === 'black') {
                    const isActive = activeKeys.has(k.note);
                    const actualNote = getTransposedNote(k.note);
                    return (
                      <button
                        key={k.note}
                        data-note={k.note}
                        onMouseDown={() => handleMouseDownKey(k.note)}
                        onMouseEnter={() => handleMouseEnterKey(k.note)}
                        onMouseLeave={() => handleMouseLeaveKey(k.note)}
                        className={`key-black pointer-events-auto absolute w-6 sm:w-8 md:w-10 h-[62%] rounded-b-md border border-slate-900 z-10 flex flex-col justify-end pb-1.5 sm:pb-2 items-center text-[8px] sm:text-[9px] font-bold transition-none shadow-xl select-none touch-none ${
                          isActive
                            ? 'key-pressed-active bg-amber-500 text-slate-950 shadow-[0_0_15px_rgba(245,158,11,0.9)]'
                            : 'bg-slate-900 text-slate-200'
                        }`}
                        style={{
                          transform: 'translateX(-50%)',
                          left: `${(GAMEPLAY_KEYS.slice(0, idx).filter((x) => x.type === 'white').length / GAMEPLAY_KEYS.filter((x) => x.type === 'white').length) * 100}%`,
                        }}
                      >
                        <span className="text-[8px] sm:text-[9px] font-bold">{actualNote}</span>
                      </button>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3 PUNTINI (...) MODAL POPUP PER TUTTE LE SCELTE ED OPZIONI */}
      {isOptionsModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-slate-850 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-white text-sm">Opzioni & Strumenti Pianoforte</h3>
              </div>
              <button
                onClick={() => setIsOptionsModalOpen(false)}
                className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Options */}
            <div className="p-4 space-y-4 overflow-y-auto text-xs">
              {/* Selezione Tipologia Tastiera */}
              <div>
                <label className="text-slate-400 font-bold uppercase text-[10px] tracking-wider block mb-2">
                  Tipologia Tastiera & Estensione
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'compact', label: 'Compatta (C4-C6)', desc: '2 Ottave, Tasti ampi' },
                    { id: 'balanced', label: 'Bilanciata (C3-G5)', desc: 'Standard ottimizzato' },
                    { id: 'extended', label: 'Estesa (C3-C6)', desc: '3 Ottave complete' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setKeyboardLayout(item.id as KeyboardLayoutType)}
                      className={`p-2.5 rounded-xl text-left border transition-all flex flex-col justify-between ${
                        keyboardLayout === item.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                          : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold">
                        <span>{item.label}</span>
                        {keyboardLayout === item.id && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Selezione Strumento */}
              <div>
                <label className="text-slate-400 font-bold uppercase text-[10px] tracking-wider block mb-2">
                  Timbro Strumento
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['piano', 'guitar', 'strings', 'bass'] as InstrumentType[]).map((inst) => (
                    <button
                      key={inst}
                      onClick={() => setInstrument(inst)}
                      className={`p-2.5 rounded-xl capitalize font-bold text-left flex items-center justify-between border transition-all ${
                        instrument === inst
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span>{inst}</span>
                      {instrument === inst && <Check className="w-3.5 h-3.5 text-amber-400" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Controlli Audio */}
              <div>
                <label className="text-slate-400 font-bold uppercase text-[10px] tracking-wider block mb-2">
                  Effetti & Tasti
                </label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <div>
                      <div className="font-bold text-white">Pedale Sustain</div>
                      <div className="text-[10px] text-slate-400">Lascia risuonare le note dopo il rilascio</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={sustain}
                      onChange={(e) => {
                        setSustain(e.target.checked);
                        audioEngine.setSustain(e.target.checked);
                      }}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  {isPortrait && (
                    <div className="flex items-center justify-between bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                      <div>
                        <div className="font-bold text-white">Forza Orizzontale</div>
                        <div className="text-[10px] text-slate-400">Ruota il piano a 90° in verticale</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={forceLandscape}
                        onChange={(e) => setForceLandscape(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Profilo & Spartiti */}
              <div>
                <label className="text-slate-400 font-bold uppercase text-[10px] tracking-wider block mb-2">
                  Spartiti & Community
                </label>
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setIsOptionsModalOpen(false);
                      setIsLibraryOpen(true);
                    }}
                    className="w-full p-2.5 bg-slate-800 hover:bg-slate-750 text-white font-bold rounded-xl flex items-center justify-between border border-slate-700"
                  >
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-amber-400" />
                      <span>Libreria Spartiti & Community</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Apri &rarr;</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsOptionsModalOpen(false);
                      toggleRecording();
                    }}
                    className={`w-full p-2.5 font-bold rounded-xl flex items-center justify-between border transition-all ${
                      isRecording
                        ? 'bg-red-500/20 border-red-500 text-red-300'
                        : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${isRecording ? 'bg-red-500 animate-ping' : 'bg-red-500'}`} />
                      <span>{isRecording ? 'Termina Registrazione Brano' : 'Registra Nuovo Spartito'}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">{isRecording ? 'Stop' : 'Inizia'}</span>
                  </button>
                </div>
              </div>

              {/* Informazione Glissando */}
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300/90 text-[11px] flex items-start gap-2">
                <Sparkles className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  <strong>Glissando e scale continue:</strong> trascina il dito lungo la tastiera per far suonare ogni tasto al passaggio senza dover staccare e riattaccare.
                </span>
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-850 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setIsOptionsModalOpen(false)}
                className="px-4 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs hover:bg-amber-400"
              >
                Chiudi
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Song Library & Creator Modal */}
      <SongLibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        onSelectSongToPlay={(song) => {
          setActiveSong(song);
          setShowWaterfall(true);
        }}
        currentUsername={username}
        onUsernameChange={(newName) => setUsernameState(newName)}
        newRecordedSongData={newRecordedSongData}
        onClearRecordedData={() => setNewRecordedSongData(null)}
      />
    </div>
  );
};
