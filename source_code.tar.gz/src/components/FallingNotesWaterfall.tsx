import React, { useEffect, useRef, useState, useCallback } from 'react';
import { InteractiveSong } from '../types';
import { audioEngine } from '../utils/audioEngine';
import { Play, Pause, RotateCcw, Volume2, Sparkles, Award, Zap, BookOpen, X, ChevronDown, Check } from 'lucide-react';

interface KeyConfig {
  note: string;
  type: 'white' | 'black';
  octave: number;
}

interface FallingNotesWaterfallProps {
  song: InteractiveSong;
  keys: KeyConfig[];
  getTransposedNote: (note: string) => string;
  onKeyPressExpected?: (note: string) => void;
  onActiveSongChange?: (song: InteractiveSong) => void;
  onClose: () => void;
  lastPlayedNote: { note: string; timestamp: number } | null;
}

export const FallingNotesWaterfall: React.FC<FallingNotesWaterfallProps> = React.memo(({
  song,
  keys,
  getTransposedNote,
  onClose,
  lastPlayedNote,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Playback modes: 'learn' (wait for correct key at the hit line), 'arcade' (real-time rhythm scoring), 'demo' (auto-play)
  const [playMode, setPlayMode] = useState<'learn' | 'arcade' | 'demo'>('learn');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [currentTime, setCurrentTime] = useState<number>(0);

  // Game stats
  const [score, setScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);
  const [feedback, setFeedback] = useState<{ text: string; color: string; id: number } | null>(null);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [waitingTargetNote, setWaitingTargetNote] = useState<string | null>(null);

  // Refs for animation loop
  const isPlayingRef = useRef<boolean>(isPlaying);
  isPlayingRef.current = isPlaying;

  const playModeRef = useRef<'learn' | 'arcade' | 'demo'>(playMode);
  playModeRef.current = playMode;

  const playbackSpeedRef = useRef<number>(playbackSpeed);
  playbackSpeedRef.current = playbackSpeed;

  const currentTimeRef = useRef<number>(0);
  const lastUiUpdateTimeRef = useRef<number>(0);
  const lastFrameTimeRef = useRef<number>(performance.now());
  const animationFrameRef = useRef<number | null>(null);

  // Track which notes have been hit or auto-played
  const hitNotesSetRef = useRef<Set<number>>(new Set());
  // The note currently waiting to be pressed in 'learn' mode
  const waitingNoteIndexRef = useRef<number | null>(null);

  // Total song length
  const songDuration = Math.max(...song.notes.map((n) => n.time + n.duration), 5);

  // Falling speed: time in seconds a note takes to travel from top to hit line
  const TRAVEL_TIME = 2.4; // 2.4 seconds scroll time

  // Build key lane mapping for fast X-coordinate lookup
  const whiteKeys = keys.filter((k) => k.type === 'white');
  const numWhiteKeys = whiteKeys.length;

  const getKeyPosition = useCallback((noteName: string, canvasWidth: number) => {
    // Normalise note name
    const whiteWidth = canvasWidth / numWhiteKeys;
    const whiteIdx = whiteKeys.findIndex((k) => k.note === noteName);

    if (whiteIdx !== -1) {
      return {
        x: whiteIdx * whiteWidth,
        width: whiteWidth,
        type: 'white' as const,
      };
    }

    // Black key
    const allIdx = keys.findIndex((k) => k.note === noteName);
    if (allIdx !== -1) {
      // Find neighboring white key
      let whiteCountBefore = 0;
      for (let i = 0; i < allIdx; i++) {
        if (keys[i].type === 'white') whiteCountBefore++;
      }
      const blackWidth = whiteWidth * 0.65;
      const x = whiteCountBefore * whiteWidth - blackWidth / 2;
      return {
        x,
        width: blackWidth,
        type: 'black' as const,
      };
    }

    return { x: 0, width: whiteWidth, type: 'white' as const };
  }, [keys, whiteKeys, numWhiteKeys]);

  // Handle note played (via direct event or props)
  const processPlayedNote = useCallback((playedNote: string) => {
    const curTime = currentTimeRef.current;

    if (playModeRef.current === 'learn') {
      const waitingIdx = waitingNoteIndexRef.current;
      if (waitingIdx !== null) {
        const expectedNote = song.notes[waitingIdx];
        if (expectedNote && (expectedNote.note === playedNote || getTransposedNote(expectedNote.note) === playedNote)) {
          // Correct note in learn mode!
          hitNotesSetRef.current.add(waitingIdx);
          waitingNoteIndexRef.current = null;
          setWaitingTargetNote(null);
          setScore((s) => s + 100);
          setCombo((c) => {
            const next = c + 1;
            setMaxCombo((m) => Math.max(m, next));
            return next;
          });
          setFeedback({ text: 'PERFETTO! 🌟', color: 'text-amber-400', id: Date.now() });
          setIsPlaying(true);
        }
      }
    } else if (playModeRef.current === 'arcade') {
      // Find note near hit line
      let bestIdx = -1;
      let minDiff = 999;

      song.notes.forEach((n, idx) => {
        if (hitNotesSetRef.current.has(idx)) return;
        const diff = Math.abs(n.time - curTime);
        if (diff < 0.35 && (n.note === playedNote || getTransposedNote(n.note) === playedNote)) {
          if (diff < minDiff) {
            minDiff = diff;
            bestIdx = idx;
          }
        }
      });

      if (bestIdx !== -1) {
        hitNotesSetRef.current.add(bestIdx);
        const pts = minDiff < 0.15 ? 100 : 50;
        setScore((s) => s + pts);
        setCombo((c) => {
          const next = c + 1;
          setMaxCombo((m) => Math.max(m, next));
          return next;
        });
        setFeedback({
          text: pts === 100 ? 'PERFETTO! +100 🎯' : 'BUONO! +50 👍',
          color: pts === 100 ? 'text-amber-300' : 'text-emerald-400',
          id: Date.now(),
        });
      }
    }
  }, [song.notes, getTransposedNote]);

  useEffect(() => {
    if (lastPlayedNote) {
      processPlayedNote(lastPlayedNote.note);
    }
  }, [lastPlayedNote, processPlayedNote]);

  useEffect(() => {
    const handleEvent = (e: Event) => {
      const custom = e as CustomEvent<{ note: string }>;
      if (custom.detail?.note) {
        processPlayedNote(custom.detail.note);
      }
    };
    window.addEventListener('piano:noteplayed', handleEvent);
    return () => window.removeEventListener('piano:noteplayed', handleEvent);
  }, [processPlayedNote]);

  // Main canvas animation render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.floor(rect.width * dpr);
        canvas.height = Math.floor(rect.height * dpr);
      }
    };

    resizeCanvas();
    const handleResize = () => {
      resizeCanvas();
      setTimeout(resizeCanvas, 50);
      setTimeout(resizeCanvas, 200);
      setTimeout(resizeCanvas, 400);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    lastFrameTimeRef.current = performance.now();



    const render = (now: number) => {
      const dt = (now - lastFrameTimeRef.current) / 1000;
      lastFrameTimeRef.current = now;

      const rect = containerRef.current?.getBoundingClientRect();
      const width = rect?.width || 800;
      const height = rect?.height || 260;
      const dpr = window.devicePixelRatio || 1;

      // Ensure canvas internal resolution matches CSS display size
      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
      }

      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Target line is at 88% of canvas height (right before keys)
      const hitLineY = height - 20;

      if (isPlayingRef.current) {
        let newTime = currentTimeRef.current + dt * playbackSpeedRef.current;

        // Check 'learn' mode: pause if any unhit note reaches the hit line
        if (playModeRef.current === 'learn') {
          for (let i = 0; i < song.notes.length; i++) {
            if (!hitNotesSetRef.current.has(i)) {
              const n = song.notes[i];
              if (newTime >= n.time) {
                // Lock at note time until user presses key
                newTime = n.time;
                waitingNoteIndexRef.current = i;
                setIsPlaying(false);
                setWaitingTargetNote(n.note);
                break;
              }
            }
          }
        }

        // Check 'demo' mode: auto-play note as it crosses hit line
        if (playModeRef.current === 'demo') {
          song.notes.forEach((n, idx) => {
            if (!hitNotesSetRef.current.has(idx) && newTime >= n.time) {
              hitNotesSetRef.current.add(idx);
              audioEngine.playNote(getTransposedNote(n.note), '4n', 'piano');
            }
          });
        }

        currentTimeRef.current = newTime;
        if (Math.abs(newTime - lastUiUpdateTimeRef.current) >= 0.15 || newTime >= songDuration) {
          lastUiUpdateTimeRef.current = newTime;
          setCurrentTime(newTime);
        }

        if (newTime >= songDuration + 1) {
          setIsCompleted(true);
          setIsPlaying(false);
        }
      }

      const curTime = currentTimeRef.current;

      // Clear background
      ctx.clearRect(0, 0, width, height);

      // Dark gradient background with subtle key guide lines
      const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(1, '#0f172a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Draw vertical lane guides for white keys
      const whiteWidth = width / numWhiteKeys;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= numWhiteKeys; i++) {
        ctx.beginPath();
        ctx.moveTo(i * whiteWidth, 0);
        ctx.lineTo(i * whiteWidth, hitLineY);
        ctx.stroke();
      }

      // Draw Falling Notes
      const pixelsPerSecond = hitLineY / TRAVEL_TIME;

      song.notes.forEach((n, idx) => {
        const timeToHit = n.time - curTime;
        // Position on Y: when timeToHit == 0, y is hitLineY
        const yBottom = hitLineY - timeToHit * pixelsPerSecond;
        const noteHeight = Math.max(22, (n.duration || 0.4) * pixelsPerSecond * 0.7);
        const yTop = yBottom - noteHeight;

        // Skip if outside visible view
        if (yTop > height || yBottom < 0) return;

        const isHit = hitNotesSetRef.current.has(idx);
        const isWaiting = waitingNoteIndexRef.current === idx;
        const keyPos = getKeyPosition(n.note, width);

        // Styling based on white vs black key and hit state
        ctx.save();
        const noteWidth = keyPos.width - 4;
        const noteX = keyPos.x + 2;

        if (isHit && playModeRef.current !== 'demo') {
          // Dim hit notes
          ctx.fillStyle = 'rgba(100, 116, 139, 0.35)';
          ctx.beginPath();
          ctx.roundRect(noteX, yTop, noteWidth, noteHeight, 6);
          ctx.fill();
        } else {
          // Vibrant Glowing Note Block
          const isBlack = keyPos.type === 'black';
          const blockGrad = ctx.createLinearGradient(noteX, yTop, noteX + noteWidth, yBottom);

          if (isWaiting) {
            // Pulsing Gold indicator for current waiting note
            const pulse = (Math.sin(now / 150) + 1) / 2;
            blockGrad.addColorStop(0, '#fef08a');
            blockGrad.addColorStop(1, '#eab308');
            ctx.shadowColor = '#f59e0b';
            ctx.shadowBlur = 15 + pulse * 10;
          } else if (isBlack) {
            blockGrad.addColorStop(0, '#c084fc');
            blockGrad.addColorStop(1, '#9333ea');
            ctx.shadowColor = '#a855f7';
            ctx.shadowBlur = 8;
          } else {
            blockGrad.addColorStop(0, '#38bdf8');
            blockGrad.addColorStop(1, '#0284c7');
            ctx.shadowColor = '#38bdf8';
            ctx.shadowBlur = 8;
          }

          ctx.fillStyle = blockGrad;
          ctx.beginPath();
          ctx.roundRect(noteX, yTop, noteWidth, noteHeight, 6);
          ctx.fill();

          // Stroke border
          ctx.strokeStyle = isWaiting ? '#ffffff' : 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = isWaiting ? 2 : 1;
          ctx.stroke();

          // Note label text inside the block
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#ffffff';
          ctx.font = `bold ${noteWidth > 28 ? '11px' : '9px'} sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(n.note, noteX + noteWidth / 2, yBottom - 11);
        }

        ctx.restore();
      });

      // DRAW THE CRITICAL HORIZONTAL HIT LINE ("riga orizzontale che divide con i tasti")
      ctx.save();
      // Glowing background glow line
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 12;
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, hitLineY);
      ctx.lineTo(width, hitLineY);
      ctx.stroke();

      // Sharp bright core
      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#fffbeb';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, hitLineY);
      ctx.lineTo(width, hitLineY);
      ctx.stroke();

      // Hit Line targets for each key
      for (let i = 0; i < numWhiteKeys; i++) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.beginPath();
        ctx.arc(i * whiteWidth + whiteWidth / 2, hitLineY, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      ctx.restore(); // Restore dpr transform

      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [song, songDuration, numWhiteKeys, getKeyPosition, getTransposedNote]);

  const handleReset = () => {
    currentTimeRef.current = 0;
    setCurrentTime(0);
    hitNotesSetRef.current.clear();
    waitingNoteIndexRef.current = null;
    setWaitingTargetNote(null);
    setScore(0);
    setCombo(0);
    setIsCompleted(false);
    setIsPlaying(true);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    currentTimeRef.current = newTime;
    setCurrentTime(newTime);
    hitNotesSetRef.current.clear();
    waitingNoteIndexRef.current = null;
    setWaitingTargetNote(null);
  };

  return (
    <div className="flex flex-col flex-1 w-full bg-slate-950 overflow-hidden min-h-0">
      {/* Ultra-compact single-line sub-header */}
      <div className="flex items-center justify-between px-2 py-0.5 bg-slate-900/90 border-b border-slate-800 text-[11px] shrink-0 h-7">
        {/* Song info */}
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="font-bold text-amber-400 truncate max-w-[130px] sm:max-w-[200px]">🎵 {song.title}</span>
          <span className="text-[10px] text-slate-400 hidden sm:inline">• {song.author}</span>
        </div>

        {/* Compact Mode & Transport buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex items-center bg-slate-950 rounded border border-slate-800 p-0.5">
            <button
              onClick={() => { setPlayMode('learn'); handleReset(); }}
              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${playMode === 'learn' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              title="Aspetta che premi il tasto corretto"
            >
              Impara
            </button>
            <button
              onClick={() => { setPlayMode('arcade'); handleReset(); }}
              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${playMode === 'arcade' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'}`}
              title="A tempo in tempo reale"
            >
              Arcade
            </button>
            <button
              onClick={() => { setPlayMode('demo'); handleReset(); }}
              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${playMode === 'demo' ? 'bg-purple-500 text-white' : 'text-slate-400'}`}
              title="Ascolta demo automatica"
            >
              Demo
            </button>
          </div>

          <div className="text-[10px] font-bold text-amber-300 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700">
            {score} pts
          </div>
          {combo > 1 && (
            <span className="text-[10px] font-bold text-amber-400 animate-pulse hidden sm:inline">
              {combo}x
            </span>
          )}

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1 hover:bg-slate-800 text-slate-200 rounded transition-colors"
            title={isPlaying ? 'Pausa' : 'Riproduci'}
          >
            {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
          </button>
          <button
            onClick={handleReset}
            className="p-1 hover:bg-slate-800 text-slate-200 rounded transition-colors"
            title="Ricomincia"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded transition-colors"
            title="Chiudi spartito a cascata"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Waterfall Visual Canvas Container - dynamically fills available flex height */}
      <div ref={containerRef} className="relative flex-1 w-full bg-slate-950 overflow-hidden min-h-0">
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Big Crisp Waiting Prompt Banner: Crystal clear, never squished, right above keys */}
        {waitingTargetNote && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center justify-center">
            <div className="flex items-center gap-2.5 px-4 py-2 bg-slate-900/95 border-2 border-amber-400 rounded-full shadow-[0_0_25px_rgba(251,191,36,0.5)] backdrop-blur-md animate-pulse">
              <span className="text-sm font-extrabold text-amber-300 uppercase tracking-wide">
                Premi il tasto:
              </span>
              <span className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black text-sm rounded-md shadow">
                {waitingTargetNote}
              </span>
            </div>
          </div>
        )}

        {/* Live Feedback overlay (PERFECT! / GOOD!) */}
        {feedback && (
          <div
            key={feedback.id}
            className={`absolute top-4 left-1/2 -translate-x-1/2 font-extrabold text-sm sm:text-base pointer-events-none drop-shadow-md animate-bounce ${feedback.color}`}
          >
            {feedback.text}
          </div>
        )}

        {/* Song Completed Overlay */}
        {isCompleted && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center gap-2 z-20">
            <div className="p-3 bg-amber-500/20 border border-amber-500/40 rounded-full text-amber-400 animate-pulse">
              <Award className="w-8 h-8" />
            </div>
            <h3 className="text-base sm:text-lg font-black text-white">Spartito Completato con Successo! 🎉</h3>
            <p className="text-xs text-slate-300">
              Punteggio Finale: <span className="text-amber-400 font-bold">{score}</span> • Max Combo: <span className="text-cyan-400 font-bold">{maxCombo}</span>
            </p>
            <div className="flex gap-2 mt-2">
              <button
                onClick={handleReset}
                className="px-4 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs hover:bg-amber-400 shadow-lg"
              >
                Suona di Nuovo
              </button>
              <button
                onClick={onClose}
                className="px-4 py-1.5 bg-slate-800 text-slate-200 font-bold rounded-xl text-xs hover:bg-slate-700"
              >
                Torna al Pianoforte Libero
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Progress Bar Slider (Ultra-slim 14px) */}
      <div className="px-2 py-0.5 bg-slate-900 border-t border-slate-800 flex items-center gap-1.5 shrink-0 h-4">
        <span className="text-[9px] text-slate-400 font-mono">{currentTime.toFixed(1)}s</span>
        <input
          type="range"
          min="0"
          max={songDuration}
          step="0.1"
          value={currentTime}
          onChange={handleSeek}
          className="flex-1 h-1 bg-slate-700 rounded appearance-none cursor-pointer accent-amber-500"
        />
        <span className="text-[9px] text-slate-400 font-mono">{songDuration.toFixed(1)}s</span>
      </div>
    </div>
  );
});
